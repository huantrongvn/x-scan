import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import '../core/localization/language.dart';
import '../features/home/home_screen.dart';

class XApp extends StatelessWidget {
  const XApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(listenable:XLanguage.instance,builder:(context,child)=>MaterialApp(
      locale:XLanguage.instance.locale,
      supportedLocales:XLanguage.supported,
      localizationsDelegates:GlobalMaterialLocalizations.delegates,
      localeResolutionCallback:XLanguage.resolve,
      title: 'X-Scan',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.system,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF006D70)),
        scaffoldBackgroundColor: const Color(0xFFF7F9F8),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF006D70),
          brightness: Brightness.dark,
        ),
      ),
      home: const HomeScreen(),
    ));
  }
}