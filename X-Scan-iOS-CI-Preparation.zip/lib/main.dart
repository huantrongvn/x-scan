import 'dart:ui';
import 'core/localization/language.dart';
import 'package:flutter/material.dart';
import 'app/x_app.dart';
import 'core/kernel/x_kernel.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final kernel = XKernel.instance;
  final previous = FlutterError.onError;
  FlutterError.onError = (details) {
    kernel.report(details.exception, details.stack);
    previous?.call(details);
  };
  PlatformDispatcher.instance.onError = (error, stack) {
    kernel.report(error, stack);
    return false;
  };
  ErrorWidget.builder = (_) => const Material(
    child: Center(child: Text('Thành phần gặp lỗi. Hãy quay lại hoặc mở lại ứng dụng.')),
  );
  await kernel.initialize();
  await XLanguage.instance.load();
  runApp(const XApp());
  WidgetsBinding.instance.addPostFrameCallback((_) {
    kernel.markReady();
  });
}
