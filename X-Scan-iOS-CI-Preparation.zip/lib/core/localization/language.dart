import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
class XLanguage extends ChangeNotifier {
  static final instance = XLanguage();
  String value = 'system';
  static const names = {'system':'System default','en':'English','vi':'Tiếng Việt','zh-Hans':'简体中文','zh-Hant':'繁體中文','ja':'日本語','ko':'한국어','hi':'हिन्दी','id':'Bahasa Indonesia','th':'ไทย','es':'Español','pt-BR':'Português (Brasil)','fr':'Français','de':'Deutsch','ar':'العربية','ru':'Русский'};
  static Locale parse(String tag) { final a=tag.split('-'); return Locale.fromSubtags(languageCode:a.first,scriptCode:a.length>1 && a[1].length==4?a[1]:null,countryCode:a.length>1 && a[1].length==2?a[1]:null); }
  static final supported = names.keys.where((k)=>k!='system').map(parse).toList();
  Locale? get locale => value=='system'?null:parse(value);
  Future<void> load() async { final p=await SharedPreferences.getInstance(); final v=p.getString('xscan_language'); if(names.containsKey(v)) value=v!; }
  Future<void> select(String v) async { if(!names.containsKey(v)) return; value=v; notifyListeners(); final p=await SharedPreferences.getInstance(); await p.setString('xscan_language',v); }
  static Locale resolve(Locale? device, Iterable<Locale> supported) {
    if(device!=null){ for(final l in supported){if(l==device)return l;}
      if(device.languageCode=='zh') return parse(device.scriptCode=='Hant'|| {'TW','HK','MO'}.contains(device.countryCode)?'zh-Hant':'zh-Hans');
      for(final l in supported){if(l.languageCode==device.languageCode)return l;}}
    return const Locale('en');
  }
  static String t(BuildContext c,String en,String vi)=>Localizations.localeOf(c).languageCode=='vi'?vi:en;
}
