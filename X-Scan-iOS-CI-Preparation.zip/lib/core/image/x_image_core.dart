import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as im;

class XImageEdits {
  const XImageEdits({this.rotation=0,this.brightness=0,this.contrast=100,this.mode='color',this.left=0,this.top=0,this.right=0,this.bottom=0});
  final int rotation,brightness,contrast,left,top,right,bottom;
  final String mode;
}
class XImageCore {
  static Uint8List _process(Map<String,dynamic> args) {
    final source=im.decodeImage(args['bytes'] as Uint8List);
    if(source==null)throw StateError('Không đọc được ảnh');
    final e=args['edits'] as XImageEdits;
    im.Image result=im.bakeOrientation(source);
    if(args['preview'] == true && (result.width>1000 || result.height>1000)) {
      result=im.copyResize(result,width:result.width>=result.height?1000:null,height:result.height>result.width?1000:null);
    }
    final l=(result.width*e.left/100).round(),t=(result.height*e.top/100).round();
    final rr=(result.width*e.right/100).round(),b=(result.height*e.bottom/100).round();
    if(result.width-l-rr<=0||result.height-t-b<=0)throw StateError('Vùng cắt không hợp lệ');
    if(l+t+rr+b>0)result=im.copyCrop(result,x:l,y:t,width:result.width-l-rr,height:result.height-t-b);
    if(e.rotation%360!=0)result=im.copyRotate(result,angle:e.rotation);
    switch(e.mode){
      case 'gray': result=im.grayscale(result);break;
      case 'bw': result=im.luminanceThreshold(im.grayscale(result),threshold:0.52);break;
      case 'text': result=im.adjustColor(im.grayscale(result),contrast:1.55);break;
      case 'auto': result=im.adjustColor(result,contrast:1.14,saturation:1.08);break;
      case 'vivid': result=im.adjustColor(result,saturation:1.35,contrast:1.1);break;
      case 'sharp': result=im.convolution(result,filter:[0,-1,0,-1,5,-1,0,-1,0]);break;
      case 'warm': result=im.sepia(result,amount:0.25);break;
      case 'cool': result=im.adjustColor(result,hue:0.06);break;
      case 'sepia': result=im.sepia(result);break;
      case 'vintage': result=im.sepia(im.adjustColor(result,contrast:0.85),amount:0.65);break;
      case 'negative': result=im.invert(result);break;
    }
    if(e.brightness!=0||e.contrast!=100)result=im.adjustColor(result,brightness:e.brightness/100,contrast:e.contrast/100);
    return Uint8List.fromList(im.encodeJpg(result,quality:args['preview']==true?78:92));
  }
  static Future<Uint8List> preview(Uint8List bytes,XImageEdits edits)=>compute(_process,{'bytes':bytes,'edits':edits,'preview':true});
  static Future<void> render(File source,File target,XImageEdits edits) async {
    final bytes=await compute(_process,{'bytes':await source.readAsBytes(),'edits':edits,'preview':false});
    await target.parent.create(recursive:true);await target.writeAsBytes(bytes,flush:true);
  }
}
