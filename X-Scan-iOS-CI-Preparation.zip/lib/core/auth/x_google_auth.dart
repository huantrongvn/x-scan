import 'package:google_sign_in/google_sign_in.dart';

/// Google SSO without an X-Scan backend. Drive authorization is separate.
class XGoogleAuth {
  XGoogleAuth._();
  static final XGoogleAuth instance = XGoogleAuth._();
  final GoogleSignIn _google = GoogleSignIn.instance;
  Future<void>? _initializing;

  Future<void> initialize() => _initializing ??= _google.initialize(serverClientId: '944847925782-o94ef12tppftjq28s5oa9s6pslvbd8d8.apps.googleusercontent.com');

  Future<GoogleSignInAccount?> signIn() async {
    await initialize();
    if (!_google.supportsAuthenticate()) {
      throw UnsupportedError('Google Sign-In không hỗ trợ trên nền tảng này.');
    }
    return _google.authenticate();
  }

  Future<GoogleSignInAccount?> restore() async {
    await initialize();
    return _google.attemptLightweightAuthentication();
  }

  Future<void> signOut() async {
    await initialize();
    await _google.signOut();
  }
}
