import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:image/image.dart' as im;
import 'package:path_provider/path_provider.dart';

im.Image stamp(im.Image source, Uint8List icon) {
  final width=source.width < 320 ? 320 : source.width;
  final footer=(width*0.055).round().clamp(38,160).toInt();
  final out=im.Image(width:width,height:source.height+footer);
  im.fill(out,color:im.ColorRgb8(255,255,255));
  im.compositeImage(out,source,dstX:(width-source.width)~/2);
  final logo=im.decodeImage(icon);
  final font=width>=650?im.arial24:im.arial14;
  final x=width-(width>=650?270:180);
  if(logo!=null) im.compositeImage(out,im.copyResize(logo,width:footer-10,height:footer-10),dstX:x,dstY:source.height+5);
  im.drawString(out,'Scanned by X-Scan',font:font,x:x+footer-5,y:source.height+(footer-24)~/2,color:im.ColorRgb8(70,70,70));
  return out;
}
Future<List<String>> renderImages(Map<String,dynamic> args) async {
  final paths=(args['paths'] as List).cast<String>();
  final icon=args['icon'] as Uint8List;
  final clean=args['clean'] as bool;
  final long=args['long'] as bool;
  final dir=args['dir'] as String;
  final outputs=<String>[];
  final parts=<im.Image>[];
  var height=0;
  for(final path in paths){
    final decoded=im.decodeImage(await File(path).readAsBytes());
    if(decoded==null) throw StateError('Invalid image');
    final oriented=im.bakeOrientation(decoded);
    if(long){ final part=im.copyResize(oriented,width:1080); height+=part.height;
      if(height>16000) throw StateError('Image exceeds 16000 px; select fewer pages');
      parts.add(part);
    }else{
      final out='$dir/X-Scan_${outputs.length+1}.jpg';
      await File(out).writeAsBytes(im.encodeJpg(clean?oriented:stamp(oriented,icon),quality:92));outputs.add(out);
    }
  }
  if(long){final joined=im.Image(width:1080,height:height);var y=0;for(final part in parts){im.compositeImage(joined,part,dstY:y);y+=part.height;}
    final out='$dir/X-Scan_Long.jpg';await File(out).writeAsBytes(im.encodeJpg(clean?joined:stamp(joined,icon),quality:92));outputs.add(out);}
  return outputs;
}
class XImageExport {
  static Future<void> save(List<File> files,{required bool long,required bool clean}) async {
    final temp=await (await getTemporaryDirectory()).createTemp('xscan_export_');
    try{final asset=await rootBundle.load('assets/xscan_icon.png');
      final outputs=await compute(renderImages,{'paths':files.map((f)=>f.path).toList(),'icon':asset.buffer.asUint8List(asset.offsetInBytes,asset.lengthInBytes),'long':long,'clean':clean,'dir':temp.path});
      for(final path in outputs){await const MethodChannel('xscan/gallery').invokeMethod<void>('save',path);}
    }finally{await temp.delete(recursive:true);}
  }
}
