import 'package:flutter/services.dart';
import '../ads/x_reward.dart';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart' as pw_format;
import 'package:pdf/widgets.dart' as pw;
import 'package:pdfx/pdfx.dart';
import 'package:share_plus/share_plus.dart';

class XPdfExporter {
  static Future<void> export(BuildContext context, File original) async {
    final clean=await XReward.choose(context);
    if(clean==null || !context.mounted)return;
    File output;
    if (clean) {
      final tmp = await getTemporaryDirectory();
      output = await original.copy('${tmp.path}${Platform.pathSeparator}X-Scan_${DateTime.now().microsecondsSinceEpoch}.pdf'); // Preserve PDF bytes and OCR.
    } else {
      output = await _watermarkedCopy(original);
    }
    await SharePlus.instance.share(
      ShareParams(files: [XFile(output.path)], text: 'X-Scan PDF'),
    );
  }

  static Future<File> _watermarkedCopy(File source) async {
    // MVP: render each page as an image and add watermark to a new PDF.
    // Rasterization means existing selectable text / links are not retained.
    final input = await PdfDocument.openFile(source.path);
    final output = pw.Document(compress: true, title: 'X-Scan PDF', creator: 'X-Scan', author: 'X-Scan');
    final asset=await rootBundle.load('assets/xscan_icon.png');
    final logo=pw.MemoryImage(asset.buffer.asUint8List(asset.offsetInBytes,asset.lengthInBytes));
    try {
      for (var i = 1; i <= input.pagesCount; i++) {
        final page = await input.getPage(i);
        try {
          final image = await page.render(
            width: page.width * 1.5,
            height: page.height * 1.5,
            format: PdfPageImageFormat.png,
          );
          if (image == null) throw StateError('Khong render duoc trang $i');
          final memoryImage = pw.MemoryImage(image.bytes);
          output.addPage(
            pw.Page(
              pageFormat: pw_format.PdfPageFormat(page.width, page.height),
              margin: pw.EdgeInsets.zero,
              build: (_) => pw.Stack(
                children: [
                  pw.Positioned(
                    left: 0,
                    top: 0,
                    child: pw.Image(
                      memoryImage,
                      width: page.width,
                      height: page.height,
                      fit: pw.BoxFit.fill,
                    ),
                  ),
                  pw.Positioned(
                    bottom: 14,
                    right: 14,
                    child: pw.Opacity(
                      opacity: 0.55,
                      child: pw.Row(mainAxisSize:pw.MainAxisSize.min,children:[pw.Image(logo,width:16,height:16),pw.SizedBox(width:4),pw.Text(
                        'Scanned by X-Scan',
                        style: pw.TextStyle(
                          color: pw_format.PdfColors.grey700,
                          fontSize: 11,
                        ),
                      )]),
                    ),
                  ),
                ],
              ),
            ),
          );
        } finally {
          await page.close();
        }
      }
    } finally {
      await input.close();
    }
    final tmp = await getTemporaryDirectory();
    final name = 'X-Scan_${DateTime.now().microsecondsSinceEpoch}.pdf';
    final target = File('${tmp.path}${Platform.pathSeparator}$name');
    await target.writeAsBytes(await output.save(), flush: true);
    return target;
  }
}
