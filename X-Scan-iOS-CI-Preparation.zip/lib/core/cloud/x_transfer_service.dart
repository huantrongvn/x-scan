import 'x_shortlink_service.dart';

import 'dart:convert';
import 'dart:io';

import 'package:google_sign_in/google_sign_in.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'x_drive_client.dart';

class XTransferService {
  XTransferService(this.drive);
  final XDriveClient drive;

  static const _cleanupKey = 'checo_transfer_cleanup_v1';

  Future<String> send(GoogleSignInAccount account, List<File> files) async {
    if (files.isEmpty) throw StateError('Chưa chọn tệp');
    final folder = await drive.createShareFolder(account);
    final prefs = await SharedPreferences.getInstance();
    // Register before upload, so partial failures can be cleaned up later.
    final pending = prefs.getStringList(_cleanupKey) ?? <String>[];
    pending.add(
      jsonEncode({
        'id': folder,
        'owner': account.email,
        'expiresAt': DateTime.now()
            .toUtc()
            .add(const Duration(hours: 1))
            .toIso8601String(),
      }),
    );
    if (!await prefs.setStringList(_cleanupKey, pending)) {
      throw StateError('Không thể ghi lịch dọn dẹp; không tiếp tục tải lên');
    }
    for (final file in files) {
      final uploaded = await drive.uploadFile(account, folder, file);
      await drive.makePublicReadOnly(account, uploaded['id'] as String);
    }
    await drive.makePublicReadOnly(account, folder);
    return XShortlinkService.create(
      account,
      folder,
      'X-Transfer (${files.length} tệp)',
    );
  }

  Future<void> cleanup(GoogleSignInAccount account) async {
    final prefs = await SharedPreferences.getInstance();
    final pending = prefs.getStringList(_cleanupKey) ?? <String>[];
    final keep = <String>[];
    for (final raw in pending) {
      try {
        final item = jsonDecode(raw) as Map<String, dynamic>;
        if (item['owner'] != account.email ||
            DateTime.parse(item['expiresAt'] as String)
                .isAfter(DateTime.now().toUtc())) {
          keep.add(raw);
          continue;
        }
        await drive.deleteFile(account, item['id'] as String);
      } catch (_) {
        keep.add(raw);
      }
    }
    await prefs.setStringList(_cleanupKey, keep);
  }
}
