import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'x_sync_quota.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../features/scan/scan_repository.dart';

class XScanSyncService {
  static const scopes = ['https://www.googleapis.com/auth/drive.appdata', 'https://www.googleapis.com/auth/drive.file'];
  final _http = http.Client();
  void dispose() => _http.close();

  static bool busy = false;
  Future<String> sync(GoogleSignInAccount account, {bool automatic = false, String? folderId}) async {
    if (busy) return 'Sync already running';
    busy = true;
    try { return await _sync(account, automatic, folderId); } finally { busy = false; }
  }
  Future<String> _sync(GoogleSignInAccount account, bool automatic, String? folderId) async {
    final auth = account.authorizationClient;
    var headers = await auth.authorizationHeaders(scopes);
    if (headers == null && automatic) throw StateError('Cần cấp quyền Drive bằng Đồng bộ ngay');
    if (headers == null) {
      await auth.authorizeScopes(scopes);
      headers = await auth.authorizationHeaders(scopes);
    }
    if (headers == null) throw StateError('Chưa cấp quyền Google Drive');
    final h = headers;
    final prefs = await SharedPreferences.getInstance();
    String key(String rel) => 'sync33:${account.id}:$rel';
    final updates = <String, Map<String,dynamic>>{};
    final duplicates = <String>{};
    final root = p.join((await getApplicationDocumentsDirectory()).path, 'checo');
    Future<List<Map<String,dynamic>>> list(String query, String space) async {
      final result = <Map<String,dynamic>>[];
      String? token;
      do {
        final response = await _http.get(Uri.https('www.googleapis.com','/drive/v3/files',{
          'spaces':space,'q':query,'pageSize':'1000',
          'fields':'nextPageToken,files(id,name,size,appProperties,mimeType,md5Checksum)',
          if(token != null) 'pageToken':token,
        }),headers:h).timeout(const Duration(seconds:60));
        _check(response);
        final data=jsonDecode(response.body) as Map<String,dynamic>;
        result.addAll((data['files'] as List).cast<Map<String,dynamic>>());
        token=data['nextPageToken'] as String?;
      } while(token != null);
      return result;
    }
    Future<String> createFolder(String name, String tag, String parent) async {
      final r=await _http.post(Uri.https('www.googleapis.com','/drive/v3/files',{'fields':'id'}), headers:{...h,'Content-Type':'application/json'},body:jsonEncode({'name':name,'mimeType':'application/vnd.google-apps.folder','parents':[parent],'folderColorRgb':'#16a765','appProperties':{'xscanFolder':tag}})).timeout(const Duration(seconds:60));
      _check(r); return jsonDecode(r.body)['id'] as String;
    }
    final roots=await list("trashed = false and 'root' in parents and appProperties has { key='xscanFolder' and value='root-v3' }",'drive');
    if(roots.length>1) throw StateError('Có nhiều thư mục gốc X-Scan; cần kiểm tra');
    final driveRoot=roots.isEmpty ? await createFolder('X-Scan','root-v3','root') : roots.single['id'] as String;
    final children=await list("trashed = false and '$driveRoot' in parents",'drive');
    final mapped=<String,Map<String,dynamic>>{};
    final remote=<Map<String,dynamic>>[];
    for(final child in children){
      final tag=(child['appProperties'] as Map?)?['xscanFolder'];
      if(tag is! String || !RegExp(r'^\d+$').hasMatch(tag)) continue;
      if(mapped.containsKey(tag)) throw StateError('Trùng ID tài liệu trên Drive');
      mapped[tag]=child;
      final entries=await list("trashed = false and '${child['id']}' in parents",'drive');
      for(final entry in entries){
        final rel=(entry['appProperties'] as Map?)?['rel'];
        if(rel is String && (rel.startsWith('scan_folders/$tag/') || rel.startsWith('scan_states/$tag/'))) remote.add({...entry,'name':rel});
      }
    }
    // Restore missing legacy files only. Never delete or overwrite legacy data.
    final legacy=await list('trashed = false','appDataFolder');
    var migrationConflicts=0;
    final blocked=<String>{};
    for(final entry in legacy){
      final rel=entry['name']; final props=entry['appProperties'];
      if(rel is! String || !_valid(rel) || props is! Map || props['kind']!='checo-scan-v1' || remote.any((e)=>e['name']==rel)) continue;
      if(folderId!=null && !rel.startsWith('scan_folders/$folderId/') && !rel.startsWith('scan_states/$folderId/')) continue;
      final local=File(p.joinAll([root,...rel.split('/')]));
      if(await local.exists()) {
        final digest=(await sha256.bind(local.openRead()).first).toString();
        if(digest!=props['sha256'] && prefs.getString('sync32:${account.id}:$rel')!=props['sha256']) {migrationConflicts++; blocked.add(rel.split('/')[1]);}
        continue;
      }
      if(prefs.containsKey(key(rel)) || prefs.containsKey('sync32:${account.id}:$rel')) {migrationConflicts++; blocked.add(rel.split('/')[1]); continue;}
      final r=await _http.get(Uri.https('www.googleapis.com','/drive/v3/files/${entry['id']}',{'alt':'media'}),headers:h).timeout(const Duration(seconds:90));
      _check(r);
      if(sha256.convert(r.bodyBytes).toString()!=props['sha256']) throw StateError('Legacy checksum mismatch');
      await local.parent.create(recursive:true);
      final temp=File('${local.path}.migration.tmp');
      await temp.writeAsBytes(r.bodyBytes,flush:true);
      if(!await local.exists()) await temp.rename(local.path); else await temp.delete();
    }
    // Brand asset is separate from document quota.
    if(!children.any((e)=>(e['appProperties'] as Map?)?['xscanLogo']=='1')) {
      final asset=await rootBundle.load('assets/xscan_icon.png');
      await _upload(h, {'name':'X-Scan.png','mimeType':'image/png','parents':[driveRoot],'appProperties':{'xscanLogo':'1'}},asset.buffer.asUint8List(asset.offsetInBytes,asset.lengthInBytes));
    }
    final known = <String, Map<String, dynamic>>{};
    final folders = <String>{for(final id in mapped.keys) 'scan_folders/$id'};
    var bytes = 0;
    var conflicts = migrationConflicts;
    var downloaded = 0;
    var uploaded = 0;
    var skipped = 0;
    int downloadRank(Map<String, dynamic> entry) {
      final name = entry['name'].toString();
      if (name.startsWith('scan_states/')) return 0;
      return name.endsWith('/folder.json') ? 2 : 1;
    }
    remote.sort((a,b) => downloadRank(a).compareTo(downloadRank(b)));
    for (final entry in remote) {
      bytes += int.tryParse('${entry['size']}') ?? 0;
      final props = entry['appProperties'];
      if (props is! Map || props['kind'] != 'checo-scan-v1') continue;
      final rel = entry['name'] as String;
      if (!_valid(rel)) continue;
      if (!rel.startsWith('scan_states/')) folders.add(_folder(rel));
      if (known.containsKey(rel)) { duplicates.add(rel); conflicts++; continue; }
      known[rel] = entry;
    }
    for (final entry in known.values) {
      final rel = entry['name'] as String;
      if (entry['md5Checksum'] != (entry['appProperties'] as Map)['md5']) { conflicts++; continue; }
      if (duplicates.contains(rel) || (folderId != null && !rel.startsWith('scan_folders/$folderId/') && !rel.startsWith('scan_states/$folderId/'))) continue;
      final props = entry['appProperties'] as Map;
      final remoteHash = props['sha256'] as String?;
      if (remoteHash == null) { conflicts++; continue; }
      final local = File(p.joinAll([root, ...rel.split('/')]));
      String? before;
      if (await local.exists()) {
        before = (await sha256.bind(local.openRead()).first).toString();
        final base = prefs.getString(key(rel));
        if (before == remoteHash) { await prefs.setString(key(rel), before); continue; }
        if (base == remoteHash && entry['md5Checksum'] == props['md5']) { updates[rel] = entry; continue; }
        if (base != before) { conflicts++; continue; }
      } else if (prefs.containsKey(key(rel))) {
        // A previously synced missing file may have been intentionally deleted.
        conflicts++; continue;
      }
      final response = await _http.get(Uri.https('www.googleapis.com', '/drive/v3/files/${entry['id']}', {'alt': 'media'}), headers: h).timeout(const Duration(seconds: 90));
      _check(response);
      if (sha256.convert(response.bodyBytes).toString() != props['sha256']) throw StateError('Dữ liệu tải về không khớp');
      await local.parent.create(recursive: true);
      {
        final temp = File('${local.path}.${DateTime.now().microsecondsSinceEpoch}.tmp');
        try {
          await temp.writeAsBytes(response.bodyBytes, flush: true);
          final current = await local.exists() ? (await sha256.bind(local.openRead()).first).toString() : null;
          if (current == before) {
            await temp.rename(local.path);
            await prefs.setString(key(rel), remoteHash);
            downloaded++;
          } else { conflicts++; }
        } finally {
          if (await temp.exists()) await temp.delete();
        }
      }
    }
    final groups = <String, List<File>>{};
    final states = <File>[];
    for (final name in ['scan_states', 'scan_folders']) {
      final dir = Directory(p.join(root, name));
      if (!await dir.exists()) continue;
      await for (final item in dir.list(recursive: true, followLinks: false)) {
        if (item is! File) continue;
        final rel = p.relative(item.path, from: root).replaceAll(Platform.pathSeparator, '/');
        if (!_valid(rel) || (known.containsKey(rel) && !updates.containsKey(rel))) continue;
        if (folderId != null && !rel.startsWith('scan_folders/$folderId/') && !rel.startsWith('scan_states/$folderId/')) continue;
        if (name == 'scan_states') { states.add(item); continue; }
        (groups[_folder(rel)] ??= []).add(item);
      }
    }
    final localFolders = await ScanRepository.folders();
    int rank(ScanFolder f) => f.pinned ? 0 : f.starred ? 1 : 2;
    localFolders.sort((a,b) { final r = rank(a).compareTo(rank(b)); return r != 0 ? r : a.createdAt.compareTo(b.createdAt); });
    for(final f in localFolders){
      if(folderId!=null && f.id!=folderId) continue;
      final cloud=mapped[f.id]; if(cloud==null) continue;
      final nameKey='sync33name:${account.id}:${f.id}';
      final base=prefs.getString(nameKey);
      final cloudName=cloud['name'] as String;
      if(cloudName==f.name){await prefs.setString(nameKey,f.name);continue;}
      if(base==f.name){f.name=cloudName;await ScanRepository.save(f);await prefs.setString(nameKey,cloudName);}
      else if(base!=cloudName){conflicts++;blocked.add(f.id);}
      else if(!blocked.contains(f.id) && (!automatic || DateTime.now().difference(await f.manifest.lastModified())>=const Duration(minutes:5))){
        final rel='scan_folders/${f.id}/folder.json';
        final manifestHash=(await sha256.bind(f.manifest.openRead()).first).toString();
        if((known[rel]?['appProperties'] as Map?)?['sha256']==manifestHash){
          final r=await _http.patch(Uri.https('www.googleapis.com','/drive/v3/files/${cloud['id']}'),headers:{...h,'Content-Type':'application/json'},body:jsonEncode({'name':f.name})).timeout(const Duration(seconds:60));
          _check(r);cloud['name']=f.name;await prefs.setString(nameKey,f.name);
        }
      }
    }
    final pending = <File>[];
    var plannedBytes = bytes;
    final plannedFolders = {...folders};
    for (final f in localFolders) {
      final key = 'scan_folders/${f.id}';
      if(blocked.contains(f.id)) continue;
      if (automatic && !f.pinned && !f.starred && !folders.contains(key) && !legacy.any((e)=>('${e['name']}').startsWith('$key/'))) continue;
      final files = groups[key] ?? <File>[];
      if (files.isEmpty) continue;
      if (automatic) {
        var recent = false;
        for (final file in [...files, f.manifest]) {
          if (DateTime.now().difference(await file.lastModified()) < const Duration(minutes: 5)) recent = true;
        }
        if (recent) continue;
      }
      var total = 0;
      for (final file in files) { final rel = p.relative(file.path, from: root).replaceAll(Platform.pathSeparator, '/'); total += await file.length() - (int.tryParse('${updates[rel]?['size']}') ?? 0); }
      if (!XSyncQuota.canUpload(currentBytes: plannedBytes, currentFolders: plannedFolders.length, uploadBytes: total < 0 ? 0 : total, newFolders: plannedFolders.contains(key) ? 0 : 1)) { skipped++; continue; }
      plannedBytes += total;
      plannedFolders.add(key);
      // Publish manifest last for newly uploaded folders.
      files.sort((a,b) => (p.basename(a.path) == 'folder.json' ? 1 : 0).compareTo(p.basename(b.path) == 'folder.json' ? 1 : 0));
      pending.addAll(files);
    }
    for (final file in states) {
      final id = p.basename(file.parent.path);
      final size = await file.length();
      if (!blocked.contains(id) && plannedFolders.contains('scan_folders/$id') && plannedBytes + size <= XSyncQuota.freeBytes) { pending.add(file); plannedBytes += size; }
    }
    for (final file in pending) {
      final rel = p.relative(file.path, from: root).replaceAll(Platform.pathSeparator, '/');
      final size = await file.length();
      final old = updates[rel];
      final delta = size - (int.tryParse('${old?['size']}') ?? 0);
      final folder = _folder(rel);
      final isState = rel.startsWith('scan_states/');
      if (!XSyncQuota.canUpload(currentBytes: bytes, currentFolders: folders.length, uploadBytes: delta < 0 ? 0 : delta, newFolders: isState || folders.contains(folder) ? 0 : 1)) { skipped++; break; }
      final digest = (await sha256.bind(file.openRead()).first).toString();
      final data = await file.readAsBytes();
      if (data.length != size || sha256.convert(data).toString() != digest) { skipped++; break; }
      final docId=rel.split('/')[1];
      final doc=localFolders.where((f)=>f.id==docId).firstOrNull;
      if(!mapped.containsKey(docId)) {
        if(doc==null) { skipped++; continue; }
        final id=await createFolder(doc.name,docId,driveRoot);
        mapped[docId]={'id':id,'name':doc.name};
        await prefs.setString('sync33name:${account.id}:$docId',doc.name);
      }
      final parent=mapped[docId]!['id'] as String;
      if(old!=null){
        final check=await _http.get(Uri.https('www.googleapis.com','/drive/v3/files/${old['id']}',{'fields':'appProperties,md5Checksum'}),headers:h).timeout(const Duration(seconds:60));
        _check(check);
        final current=jsonDecode(check.body);
        if(current['appProperties']?['sha256']!=(old['appProperties'] as Map)['sha256'] || current['md5Checksum']!=old['md5Checksum']){conflicts++;continue;}
      }
      await _upload(h,{'name':p.basename(rel),'mimeType': switch(p.extension(rel).toLowerCase()){'.jpg'||'.jpeg'=>'image/jpeg','.png'=>'image/png','.webp'=>'image/webp','.pdf'=>'application/pdf',_=>'application/json'},if(old==null)'parents':[parent],'appProperties':{'kind':'checo-scan-v1','rel':rel,'sha256':digest,'md5':md5.convert(data).toString()}},data,id:old?['id'] as String?);
      if(rel.endsWith('/folder.json') && doc!=null && mapped[docId]!['name']!=doc.name){
        final r=await _http.patch(Uri.https('www.googleapis.com','/drive/v3/files/$parent'),headers:{...h,'Content-Type':'application/json'},body:jsonEncode({'name':doc.name})).timeout(const Duration(seconds:60));
        _check(r); mapped[docId]!['name']=doc.name;
        await prefs.setString('sync33name:${account.id}:$docId',doc.name);
      }
      await prefs.setString(key(rel), digest);
      bytes += delta;
      if (!isState) folders.add(folder);
      uploaded++;
    }
    return 'Tải lên: $uploaded | Khôi phục: $downloaded | Xung đột: $conflicts | Bỏ qua do hạn mức: $skipped\nCloud: $bytes byte, ${folders.length} thư mục';
  }
  Future<void> _upload(Map<String,String> h, Map<String,dynamic> metadata,List<int> data,{String? id}) async {
    final boundary='xscan_${DateTime.now().microsecondsSinceEpoch}';
    final body=<int>[...utf8.encode('--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${jsonEncode(metadata)}\r\n--$boundary\r\nContent-Type: application/octet-stream\r\n\r\n'),...data,...utf8.encode('\r\n--$boundary--\r\n')];
    final uri=Uri.https('www.googleapis.com','/upload/drive/v3/files${id==null?'':'/$id'}',{'uploadType':'multipart','fields':'id,md5Checksum'});
    final headers={...h,'Content-Type':'multipart/related; boundary=$boundary'};
    final r=await (id==null?_http.post(uri,headers:headers,body:body):_http.patch(uri,headers:headers,body:body)).timeout(const Duration(seconds:120));
    _check(r);
    if(jsonDecode(r.body)['md5Checksum']!=md5.convert(data).toString()) throw StateError('Upload checksum mismatch');
  }
  static String _folder(String rel) => rel.startsWith('scan_folders/') ? rel.split('/').take(2).join('/') : 'scan';
  static bool _valid(String rel) {
    final parts = rel.split('/');
    if (parts.any((s) => s.toLowerCase().contains('.tmp'))) return false;
    return parts.length >= 2 && ['scan','scan_folders','scan_states'].contains(parts.first) && parts.every((s) => s.isNotEmpty && s != '.' && s != '..' && !s.startsWith('.') && !s.contains(RegExp(r'[\\:\x00-\x1f]')) && !s.toLowerCase().contains('trash')) && ['.pdf','.jpg','.jpeg','.png','.webp','.json'].contains(p.extension(rel).toLowerCase());
  }
  static void _check(http.Response response) {
    if (response.statusCode < 200 || response.statusCode >= 300) throw HttpException(response.body.contains('storageQuotaExceeded') ? 'Google Drive đã đầy (storageQuotaExceeded)' : 'Google Drive HTTP ${response.statusCode}');
  }
}
