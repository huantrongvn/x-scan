import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:google_sign_in/google_sign_in.dart';

import 'x_drive_client.dart';

class XShortlinkService {
  static const endpoint = 'https://x-scan.huan-at5b.workers.dev/api/links';
  static Future<String> create(
    GoogleSignInAccount account,
    String folder,
    String name, {
    String mode = 'transfer',
    String expiry = '1h',
    String? fileId,
  }) async {
    final client = account.authorizationClient;
    var headers = await client.authorizationHeaders(XDriveClient.scopes);
    if (headers == null) {
      await client.authorizeScopes(XDriveClient.scopes);
      headers = await client.authorizationHeaders(XDriveClient.scopes);
    }
    if (headers == null) throw StateError('Google authorization unavailable');
    final response = await http
        .post(
          Uri.parse(endpoint),
          headers: {...headers, 'Content-Type': 'application/json'},
          body: jsonEncode({
            'url': fileId == null
                ? 'https://drive.google.com/drive/folders/$folder'
                : 'https://drive.google.com/file/d/$fileId/view',
            'name': name,
            'mode': mode,
            'expiry': expiry,
          }),
        )
        .timeout(const Duration(seconds: 25));
    if (response.statusCode != 201) {
      throw HttpException('X-Scan Shortlink HTTP ${response.statusCode}');
    }
    final result = jsonDecode(response.body) as Map<String, dynamic>;
    final link = Uri.parse(result['shortUrl'] as String);
    if (link.origin != Uri.parse(endpoint).origin ||
        !link.path.startsWith('/s/')) {
      throw StateError('Invalid X-Scan link');
    }
    return link.toString();
  }
}
