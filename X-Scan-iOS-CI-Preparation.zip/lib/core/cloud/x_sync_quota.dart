/// X-Scan Free tier application quota. Does not grant Google Drive access.
/// Enforcement across devices requires trusted account-linked sync metadata.
class XSyncQuota {
  static const int freeBytes = 100 * 1024 * 1024;
  static const int freeFolders = 20;
  static bool canUpload({required int currentBytes,required int currentFolders,
    required int uploadBytes,required int newFolders}) =>
    currentBytes >= 0 && currentFolders >= 0 && uploadBytes >= 0 && newFolders >= 0 &&
    currentBytes + uploadBytes <= freeBytes &&
    currentFolders + newFolders <= freeFolders;
}
