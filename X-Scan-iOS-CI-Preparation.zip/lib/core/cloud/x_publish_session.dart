import 'dart:io';
import 'dart:convert';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'x_drive_client.dart';
import 'x_shortlink_service.dart';

typedef PublishProgress = void Function(int percent, int done, int bytes, int total, String stage);

class XPublishSession {
  XPublishSession(this.drive, this.files, this.mode, this.expiry);
  final XDriveClient drive;
  final List<File> files;
  final String mode, expiry;
  String? folder, owner, link;
  final ids = <String>[];
  bool public = false;
  bool running = false;
  String get key => mode == 'share' ? 'checo_share_cleanup_v1' : 'checo_transfer_cleanup_v1';
  Future<void> schedule(GoogleSignInAccount account, Duration duration) async {
    final prefs = await SharedPreferences.getInstance();
    final records = prefs.getStringList(key) ?? <String>[];
    records.removeWhere((raw) { try { final m = jsonDecode(raw); return m['id'] == folder && m['owner'] == account.email; } catch (_) { return false; } });
    records.add(jsonEncode({'id': folder, 'owner': account.email, 'expiresAt': DateTime.now().toUtc().add(duration).toIso8601String()}));
    if (!await prefs.setStringList(key, records)) throw StateError('Không thể lưu lịch dọn dẹp');
  }
  Future<String> run(GoogleSignInAccount account, PublishProgress progress) async {
    if (running) throw StateError('Đang xử lý');
    if (owner != null && owner != account.email) throw StateError('Tài khoản Google đã thay đổi');
    if (link != null) return link!;
    running = true;
    owner = account.email;
    try {
      final sizes = await Future.wait(files.map((f) => f.length()));
      final total = sizes.fold<int>(0, (a,b) => a+b);
      var bytes = sizes.take(ids.length).fold<int>(0, (a,b) => a+b);
      int percent(int n) => total == 0 ? 5 : 5 + (85*n/total).floor();
      progress(folder == null ? 0 : percent(bytes), ids.length, bytes, total, 'Chuẩn bị');
      folder ??= await drive.createShareFolder(account);
      if (expiry != 'never') await schedule(account, const Duration(days: 1));
      for (var i = ids.length; i < files.length; i++) {
        final result = await drive.uploadFile(account, folder!, files[i], onBytes: (n) {
          progress(percent(bytes+n), ids.length, bytes+n, total, 'Đang tải lên Google Drive');
        });
        ids.add(result['id'] as String);
        bytes += sizes[i];
        progress(percent(bytes), ids.length, bytes, total, 'Đang tải lên Google Drive');
      }
      progress(90, ids.length, total, total, 'Cấp quyền chia sẻ');
      if (!public) { await drive.makePublicReadOnly(account, folder!); public = true; }
      progress(95, ids.length, total, total, 'Đang tạo liên kết X-Scan');
      final value = await XShortlinkService.create(account, folder!, 'X-${mode == 'share' ? 'Share' : 'Transfer'} (${files.length} tệp)', mode: mode, expiry: expiry, fileId: mode != 'transfer' && ids.length == 1 ? ids.single : null);
      if (expiry != 'never') await schedule(account, Duration(hours: expiry == '12h' ? 12 : 1));
      link = value;
      progress(100, ids.length, total, total, 'Tạo liên kết thành công');
      return value;
    } finally { running = false; }
  }
}
String publishError(Object e) {
  final text = e.toString();
  if (text.contains('storageQuotaExceeded')) return 'Google Drive đã đầy. Vui lòng giải phóng dung lượng rồi thử lại.';
  if (text.contains('Shortlink')) return 'Chưa tạo được liên kết X-Scan: ${RegExp(r"HTTP [0-9]+").firstMatch(text)?.group(0) ?? "lỗi dịch vụ"}. Vui lòng thử lại.';
  return 'Không thể hoàn thành. Kiểm tra kết nối và quyền Google Drive rồi thử lại.';
}
