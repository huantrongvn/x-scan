import 'x_shortlink_service.dart';

import 'dart:convert';
import 'dart:io';

import 'package:google_sign_in/google_sign_in.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'x_drive_client.dart';

/// Records cleanup tasks locally. Expiry is best effort when the app runs.
class XShareService {
  final XDriveClient drive;
  XShareService(this.drive);
  static const _key = 'checo_share_cleanup_v1';

  Future<String> publish(
    GoogleSignInAccount account,
    List<File> files, {
    Duration? deleteAfter,
    void Function(int, int)? onProgress,
  }) async {
    if (files.isEmpty) throw ArgumentError('Chưa chọn tệp');
    final folderId = await drive.createShareFolder(account);
    try {
      var completed = 0;
      for (final file in files) {
        await drive.uploadFile(account, folderId, file);
        onProgress?.call(++completed, files.length);
      }
      // Drive folder must be readable to recipients to display its contents.
      await drive.makePublicReadOnly(account, folderId);
      if (deleteAfter != null) {
        final prefs = await SharedPreferences.getInstance();
        final pending = prefs.getStringList(_key) ?? <String>[];
        pending.add(
          jsonEncode({
            'id': folderId,
            'owner': account.email,
            'expiresAt': DateTime.now()
                .toUtc()
                .add(deleteAfter)
                .toIso8601String(),
          }),
        );
        await prefs.setStringList(_key, pending);
      }
      return await XShortlinkService.create(
        account,
        folderId,
        'X-Share (${files.length} ảnh)',
        mode: 'share',
        expiry: deleteAfter == null
            ? 'never'
            : deleteAfter.inHours == 12
            ? '12h'
            : '1h',
      );
    } catch (_) {
      // Do not delete uploaded content on an ambiguous network error.
      rethrow;
    }
  }

  Future<void> cleanup(GoogleSignInAccount account) async {
    final prefs = await SharedPreferences.getInstance();
    final pending = prefs.getStringList(_key) ?? <String>[];
    final remaining = <String>[];
    final now = DateTime.now().toUtc();
    for (final raw in pending) {
      try {
        final item = jsonDecode(raw) as Map<String, dynamic>;
        if (item['owner'] != account.email ||
            DateTime.parse(item['expiresAt'] as String).isAfter(now)) {
          remaining.add(raw);
          continue;
        }
        await drive.deleteFile(account, item['id'] as String);
      } catch (_) {
        remaining.add(raw);
      }
    }
    await prefs.setStringList(_key, remaining);
  }
}
