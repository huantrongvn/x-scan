import 'dart:convert';
import 'dart:io';

import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';

/// Google Drive operations are performed using the user's OAuth grant.
/// No Cloudflare administrator credentials are stored in the app.
class XDriveClient {
  static const scopes = <String>['https://www.googleapis.com/auth/drive.file'];
  final http.Client _http;
  XDriveClient({http.Client? client}) : _http = client ?? http.Client();

  Future<Map<String, String>> _headers(GoogleSignInAccount account) async {
    final client = account.authorizationClient;
    var headers = await client.authorizationHeaders(scopes);
    if (headers == null) {
      await client.authorizeScopes(scopes);
      headers = await client.authorizationHeaders(scopes);
    }
    if (headers == null) {
      throw StateError("Google Drive authorization unavailable");
    }
    return headers;
  }

  Future<Map<String, dynamic>> _jsonRequest(
    GoogleSignInAccount account,
    String method,
    Uri uri, {
    Object? body,
  }) async {
    final auth = await _headers(account);
    final headers = <String, String>{
      ...auth,
      'Content-Type': 'application/json; charset=utf-8',
    };
    final request = http.Request(method, uri)..headers.addAll(headers);
    if (body != null) request.body = jsonEncode(body);
    final streamed = await _http.send(request);
    final response = await http.Response.fromStream(streamed);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw HttpException(
        'Google Drive HTTP ${response.statusCode}: ${response.body}',
      );
    }
    return response.body.isEmpty
        ? {}
        : jsonDecode(response.body) as Map<String, dynamic>;
  }

  Future<String> createShareFolder(GoogleSignInAccount account) async {
    final now = DateTime.now().toUtc().toIso8601String().replaceAll(':', '-');
    final result = await _jsonRequest(
      account,
      'POST',
      Uri.parse('https://www.googleapis.com/drive/v3/files?fields=id'),
      body: {
        'name': 'X-Share $now',
        'mimeType': 'application/vnd.google-apps.folder',
      },
    );
    return result['id'] as String;
  }

  Future<Map<String, dynamic>> uploadFile(
    GoogleSignInAccount account,
    String folderId,
    File file, {
    void Function(int)? onBytes,
  }) async {
    final auth = await _headers(account);
    final metadata = jsonEncode({
      'name': file.uri.pathSegments.last,
      'parents': [folderId],
    });
    final request = http.MultipartRequest(
      'POST',
      Uri.parse(
        'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink',
      ),
    );
    request.headers.addAll(auth);
    request.files.add(
      http.MultipartFile.fromString(
        'metadata',
        metadata,
        contentType: MediaType('application', 'json'),
      ),
    );
    final length = await file.length();
    var sent = 0;
    final stream = file.openRead().map((chunk) {
      sent += chunk.length;
      onBytes?.call(sent);
      return chunk;
    });
    request.files.add(http.MultipartFile('file', stream, length,
      filename: file.uri.pathSegments.last));
    final response = await http.Response.fromStream(await _http.send(request));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw HttpException(
        'Google Drive upload HTTP ${response.statusCode}: ${response.body}',
      );
    }
    return jsonDecode(response.body) as Map<String, dynamic>;
  }

  Future<void> makePublicReadOnly(
    GoogleSignInAccount account,
    String fileId,
  ) async {
    await _jsonRequest(
      account,
      'POST',
      Uri.parse(
        'https://www.googleapis.com/drive/v3/files/$fileId/permissions',
      ),
      body: {'type': 'anyone', 'role': 'reader', 'allowFileDiscovery': false},
    );
  }

  Future<void> deleteFile(GoogleSignInAccount account, String fileId) async {
    await _jsonRequest(
      account,
      'DELETE',
      Uri.parse('https://www.googleapis.com/drive/v3/files/$fileId'),
    );
  }

  void dispose() => _http.close();
}
