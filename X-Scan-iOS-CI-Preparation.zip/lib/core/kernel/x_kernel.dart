import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:developer' as dev;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum XModule { scan, share, transfer, cloud, settings }

class XKernel extends ChangeNotifier {
  XKernel._();
  static final instance = XKernel._();
  final Map<XModule, WidgetBuilder> _registry = {};
  final Map<XModule, List<DateTime>> _failures = {};
  final Map<XModule, DateTime> _blocked = {};
  final Set<XModule> _disabled = {};
  final List<String> diagnostics = [];
  SharedPreferences? _prefs;
  final Set<XModule> _remoteDisabled = {};
  String remoteUrl = '';
  bool remoteBusy = false;
  String remoteStatus = 'Chưa cấu hình';
  bool safeMode = false;
  static bool needsSafeMode(int attempts, bool manual) => attempts >= 2 || manual;
  Future<void> refreshFlags() async {
    if (remoteBusy || remoteUrl.isEmpty) return;
    remoteBusy = true;
    notifyListeners();
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 5);
    try {
      final uri = Uri.parse(remoteUrl);
      if (uri.scheme != 'https' || uri.host.isEmpty || uri.userInfo.isNotEmpty) throw const FormatException('HTTPS required');
      final req = await client.getUrl(uri).timeout(const Duration(seconds: 5));
      req.followRedirects = false;
      final res = await req.close().timeout(const Duration(seconds: 5));
      if (res.statusCode != 200) throw const FormatException('HTTP status');
      final bytes = await res.fold<List<int>>([], (a,b) { if (a.length + b.length > 16384) throw const FormatException('Too large'); return a..addAll(b); }).timeout(const Duration(seconds: 5));
      final data = jsonDecode(utf8.decode(bytes));
      if (data is! Map || data['version'] != 1 || data['disabled'] is! List) throw const FormatException('Invalid schema');
      final names = data['disabled'] as List;
      final valid = XModule.values.where((m) => m != XModule.settings).map((m) => m.name).toSet();
      if (names.any((n) => n is! String || !valid.contains(n))) throw const FormatException('Unknown module');
      _remoteDisabled..clear()..addAll(XModule.values.where((m) => names.contains(m.name)));
      final snapshot = _remoteDisabled.map((m) => m.name).toList();
      _persist((p) => p.setStringList('checo_core_remote_disabled_v2', snapshot));
      remoteStatus = 'Đã cập nhật';
    } catch (_) { remoteStatus = 'Không cập nhật được; giữ cache'; }
    finally { client.close(force: true); remoteBusy = false; notifyListeners(); }
  }
  Future<void> configureRemote(String url) async {
    if (remoteBusy) return;
    final value = url.trim();
    if (value.isNotEmpty) { final u = Uri.tryParse(value); if (u == null || u.scheme != 'https' || u.host.isEmpty || u.userInfo.isNotEmpty) return; }
    if (remoteUrl != value) {
      remoteUrl = value;
      _remoteDisabled.clear();
      _persist((p) => p.setStringList('checo_core_remote_disabled_v2', []));
      _persist((p) => p.setString('checo_core_remote_url_v2', value));
    }
    remoteStatus = value.isEmpty ? 'Chưa cấu hình' : 'Chờ cập nhật';
    notifyListeners();
    await refreshFlags();
  }
  bool breakerSelfTest() {
    final id = XModule.transfer;
    if (blocked(id)) return false;
    final prior = _failures.remove(id);
    try {
      for (var i = 0; i < 3; i++) { report(StateError('Synthetic test'), null, module: id); }
      final locked = blocked(id);
      reset(id);
      final pass = locked && !blocked(id) && needsSafeMode(2, false) && !needsSafeMode(1, false);
      _recordEvent('Core self-test ${pass ? "PASS" : "FAIL"}');
      return pass;
    } finally { _blocked.remove(id); _failures.remove(id); if (prior != null) _failures[id] = prior; notifyListeners(); }
  }

  bool storageAvailable = false;
  bool _ready = false;
  Future<void> _writes = Future.value();

  Future<void> initialize() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _prefs = prefs;
      diagnostics.insertAll(0, prefs.getStringList('checo_core_logs_v2') ?? []);
      if (diagnostics.length > 100) diagnostics.removeRange(0, diagnostics.length - 100);
      final attempts = prefs.getInt('checo_core_start_attempts_v2') ?? 0;
      safeMode = needsSafeMode(attempts, prefs.getBool('checo_core_safe_v2') ?? false);
      remoteUrl = prefs.getString('checo_core_remote_url_v2') ?? '';
      if (remoteUrl.isNotEmpty) _remoteDisabled.addAll(XModule.values.where((m) => m != XModule.settings && (prefs.getStringList('checo_core_remote_disabled_v2') ?? []).contains(m.name)));
      remoteStatus = remoteUrl.isEmpty ? 'Chưa cấu hình' : 'Cache cục bộ';
      _disabled.addAll(XModule.values.where((m) => m != XModule.settings && (prefs.getStringList('checo_core_disabled_v2') ?? []).contains(m.name)));
      storageAvailable = await prefs.setInt('checo_core_start_attempts_v2', attempts + 1);
    } catch (e, s) { report(e, s); }
  }

  void _persist(Future<bool> Function(SharedPreferences) action) {
    final prefs = _prefs;
    if (prefs == null) return;
    _writes = _writes.then((_) async {
      try { if (!await action(prefs)) storageAvailable = false; }
      catch (_) { storageAvailable = false; }
    });
  }

  void markReady() {
    if (_ready) return;
    _ready = true;
    _persist((p) => p.setInt('checo_core_start_attempts_v2', 0));
  }

  void report(Object error, StackTrace? stack, {XModule? module}) {
    final now = DateTime.now();
    final line = '${now.toIso8601String()} ${module?.name ?? "core"} ${error.runtimeType}';
    diagnostics.add(line);
    if (diagnostics.length > 100) diagnostics.removeAt(0);
    dev.log(line, name: 'X-Core');
    final snapshot = List<String>.of(diagnostics);
    _persist((p) => p.setStringList('checo_core_logs_v2', snapshot));
    if (module == null) return;
    final recent = _failures.putIfAbsent(module, () => []);
    recent.removeWhere((t) => now.difference(t) > const Duration(minutes: 2));
    recent.add(now);
    if (recent.length >= 3) _blocked[module] = now.add(const Duration(minutes: 1));
  }

  void register(XModule id, WidgetBuilder factory) => _registry[id] = factory;
  Widget screen(XModule id) => _ModuleHost(id: id);
  bool disabled(XModule id) => _disabled.contains(id);
  bool allowed(XModule id) => id == XModule.settings || (!safeMode && !disabled(id) && !_remoteDisabled.contains(id));
  void setEnabled(XModule id, bool enabled) {
    if (id == XModule.settings) return;
    if (enabled) { _disabled.remove(id); } else { _disabled.add(id); }
    final snapshot = _disabled.map((m) => m.name).toList();
    _persist((p) => p.setStringList('checo_core_disabled_v2', snapshot));
    notifyListeners();
  }
  void setSafeMode(bool value) {
    safeMode = value;
    _persist((p) => p.setBool('checo_core_safe_v2', value));
    notifyListeners();
  }
  bool blocked(XModule id) => _blocked[id]?.isAfter(DateTime.now()) ?? false;
  void reset(XModule id) {
    _blocked.remove(id);
    _failures.remove(id);
    _recordEvent('Recovery reset ${id.name}');
    notifyListeners();
  }
  void diagnosticTest() => _recordEvent('Diagnostic self-test');
  void _recordEvent(String event) {
    final line = '${DateTime.now().toIso8601String()} core $event';
    diagnostics.add(line);
    if (diagnostics.length > 100) diagnostics.removeAt(0);
    final snapshot = List<String>.of(diagnostics);
    _persist((p) => p.setStringList('checo_core_logs_v2', snapshot));
    notifyListeners();
  }
  Future<bool> clearDiagnostics() async {
    diagnostics.clear();
    _persist((p) => p.setStringList('checo_core_logs_v2', []));
    await _writes;
    notifyListeners();
    return storageAvailable;
  }
  Future<void> flush() => _writes;
}

class _ModuleHost extends StatefulWidget {
  const _ModuleHost({required this.id});
  final XModule id;
  @override State<_ModuleHost> createState() => _ModuleHostState();
}
class _ModuleHostState extends State<_ModuleHost> {
  Widget? _child;
  bool failed = false;
  final kernel = XKernel.instance;
  @override Widget build(BuildContext context) => ListenableBuilder(
    listenable: kernel,
    builder: (context, _) {
      if (!kernel.allowed(widget.id)) {
        _child = null;
        return const Scaffold(body: Center(child: Text('Dịch vụ đang tạm tắt. Mở Dịch vụ / Core để khôi phục.')));
      }
      final until = kernel._blocked[widget.id];
      final blocked = until != null && DateTime.now().isBefore(until);
      if (!blocked && !failed) {
        try { return _child ??= (kernel._registry[widget.id] ?? (throw StateError('Module not registered')))(context); }
        catch (e, s) { kernel.report(e, s, module: widget.id); failed = true; }
      }
      return Scaffold(body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(blocked ? 'Dịch vụ tạm khóa trong 1 phút' : 'Dịch vụ gặp lỗi'),
        TextButton(onPressed: () => setState(() { failed = false; _child = null; }), child: const Text('Thử lại')),
      ])));
    },
  );
}

class CoreStatusScreen extends StatelessWidget {
  const CoreStatusScreen({super.key});
  @override Widget build(BuildContext context) {
    final k = XKernel.instance;
    return Scaffold(appBar: AppBar(title: const Text('X-Core')), body: ListenableBuilder(
      listenable: k,
      builder: (context, _) => ListView(children: [
        SwitchListTile(title: const Text('Chế độ an toàn'), subtitle: const Text('Tạm tắt dịch vụ; không xóa dữ liệu'), value: k.safeMode, onChanged: k.setSafeMode),
        for (final m in XModule.values.where((m) => m != XModule.settings))
          SwitchListTile(title: Text(m.name), value: !k.disabled(m), onChanged: (v) => k.setEnabled(m, v)),
        ListTile(title: const Text('Remote Feature Flags'), subtitle: Text(k.remoteStatus), onTap: k.remoteBusy ? null : () async {
          String value = k.remoteUrl;
          final result = await showDialog<String>(context: context, builder: (c) => AlertDialog(title: const Text('HTTPS JSON URL'), content: TextFormField(initialValue: value, onChanged: (v) => value = v), actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Hủy')), TextButton(onPressed: () => Navigator.pop(c, value), child: const Text('Lưu'))]));
          if (result != null) await k.configureRemote(result);
        }),
        ListTile(title: const Text('Cập nhật cấu hình từ xa'), onTap: k.remoteBusy ? null : k.refreshFlags),
        ListTile(title: const Text('Kiểm tra Circuit Breaker'), subtitle: const Text('Mô phỏng lỗi, không gây crash'), onTap: () { final pass = k.breakerSelfTest(); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(pass ? 'PASS' : 'FAIL hoặc đang khóa'))); }),
        ListTile(leading: const Icon(Icons.receipt_long), title: const Text('Nhật ký chẩn đoán'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const _DiagnosticsScreen()))),
        ListTile(leading: const Icon(Icons.restore), title: const Text('Phục hồi dịch vụ'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const _RecoveryScreen()))),
      ]),
    ));
  }
}

class _DiagnosticsScreen extends StatefulWidget {
  const _DiagnosticsScreen();
  @override State<_DiagnosticsScreen> createState() => _DiagnosticsScreenState();
}
class _DiagnosticsScreenState extends State<_DiagnosticsScreen> {
  final k = XKernel.instance;
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Nhật ký chẩn đoán')),
    body: ListenableBuilder(listenable: k, builder: (context, _) => ListView(children: [
      ListTile(title: Text('Sự kiện: ${k.diagnostics.length}/100'), subtitle: Text(k.storageAvailable ? 'Lưu cục bộ khả dụng' : 'Lưu cục bộ chưa khả dụng')),
      ListTile(title: const Text('Tạo bản ghi kiểm tra'), onTap: () async { k.diagnosticTest(); await k.flush(); if (mounted) setState(() {}); }),
      ListTile(title: const Text('Sao chép nhật ký'), onTap: () async { await Clipboard.setData(ClipboardData(text: k.diagnostics.join('\n'))); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã sao chép nhật ký'))); }),
      ListTile(title: const Text('Xóa nhật ký'), onTap: () async {
        final yes = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('Xóa nhật ký?'), content: const Text('Không xóa tài liệu hoặc tài khoản.'), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Hủy')), TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Xóa'))]));
        if (yes != true) return;
        final ok = await k.clearDiagnostics();
        if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? 'Đã xóa nhật ký' : 'Chưa xác nhận lưu thay đổi')));
      }),
      if (k.diagnostics.isEmpty) const ListTile(title: Text('Chưa có sự kiện')),
      for (final line in k.diagnostics.reversed) ListTile(title: SelectableText(line)),
    ])),
  );
}

class _RecoveryScreen extends StatelessWidget {
  const _RecoveryScreen();
  Future<void> recover(BuildContext context, List<XModule> modules) async {
    final k = XKernel.instance;
    final yes = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('Phục hồi dịch vụ?'), content: const Text('Chỉ đặt lại bộ đếm lỗi và khóa tạm thời. Không thay đổi Safe Mode, cấu hình bật/tắt, tài liệu hay tài khoản.'), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Hủy')), TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Phục hồi'))]));
    if (yes != true) return;
    for (final m in modules) { k.reset(m); }
    await k.flush();
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã đặt lại trạng thái lỗi. Mở lại dịch vụ để kiểm tra.')));
  }
  @override Widget build(BuildContext context) {
    final k = XKernel.instance;
    final modules = XModule.values.where((m) => m != XModule.settings).toList();
    return Scaffold(appBar: AppBar(title: const Text('Phục hồi dịch vụ')), body: ListenableBuilder(listenable: k, builder: (context, _) => ListView(children: [
      const ListTile(title: Text('Không xóa dữ liệu'), subtitle: Text('Safe Mode và cấu hình bật/tắt được giữ nguyên.')),
      for (final m in modules) ListTile(title: Text(m.name), subtitle: Text(k.blocked(m) ? 'Đang khóa tạm thời' : !k.allowed(m) ? 'Đang tắt' : 'Sẵn sàng'), trailing: TextButton(onPressed: () => recover(context, [m]), child: const Text('Phục hồi'))),
      ListTile(title: const Text('Phục hồi toàn bộ module'), onTap: () => recover(context, modules)),
    ])));
  }
}
