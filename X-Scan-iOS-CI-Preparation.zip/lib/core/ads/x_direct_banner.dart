import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
/// Configure with --dart-define=CHECO_ADS_CONFIG_URL=https://your-domain/config.json
class XDirectBanner extends StatefulWidget {const XDirectBanner({super.key});@override State<XDirectBanner> createState()=>_State();}
class _State extends State<XDirectBanner> {
  static const endpoint=String.fromEnvironment('CHECO_ADS_CONFIG_URL');
  Map<String,dynamic>? campaign;
  @override void initState(){super.initState();load();}
  Future<void> load() async {
    if(endpoint.isEmpty||!endpoint.startsWith('https://'))return;
    final prefs=await SharedPreferences.getInstance();
    var raw=prefs.getString('checo_ad_config');
    final last=prefs.getInt('checo_ad_check')??0;
    if(DateTime.now().millisecondsSinceEpoch-last>86400000){
      try{final response=await http.get(Uri.parse(endpoint)).timeout(const Duration(seconds:5));
        if(response.statusCode==200&&response.body.length<32768){raw=response.body;await prefs.setString('checo_ad_config',raw);await prefs.setInt('checo_ad_check',DateTime.now().millisecondsSinceEpoch);}
      }catch(_){/* Use cache when offline */}
    }
    if(raw==null)return;
    try{final json=jsonDecode(raw) as Map<String,dynamic>;
      if(json['enabled']!=true)return;
      final banner=json['banner'] as Map<String,dynamic>;
      final image=Uri.tryParse(banner['imageUrl']?.toString()??'');
      final target=Uri.tryParse(banner['clickUrl']?.toString()??'');
      final now=DateTime.now();
      final start=DateTime.tryParse(banner['startAt']?.toString()??'');
      final end=DateTime.tryParse(banner['endAt']?.toString()??'');
      if(image?.scheme!='https'||target?.scheme!='https'||(start!=null&&now.isBefore(start))||(end!=null&&now.isAfter(end)))return;
      if(mounted)setState(()=>campaign=banner);
    }catch(_){/* Ignore invalid campaign */}
  }
  @override Widget build(BuildContext context){final ad=campaign;if(ad==null)return const SizedBox.shrink();
    return Container(color:Theme.of(context).scaffoldBackgroundColor,height:72,width:double.infinity,padding:const EdgeInsets.symmetric(horizontal:12,vertical:4),child:InkWell(
      onTap:()async{final u=Uri.tryParse(ad['clickUrl'].toString());if(u!=null&&u.scheme=='https')await launchUrl(u,mode:LaunchMode.externalApplication);},
      child:Stack(children:[Positioned.fill(child:Image.network(ad['imageUrl'].toString(),fit:BoxFit.contain,errorBuilder:(_,__,___)=>const SizedBox.shrink())),const Positioned(right:0,top:0,child:Text('Quảng cáo',style:TextStyle(fontSize:10)))])));
  }
}
