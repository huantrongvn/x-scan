import 'package:flutter/material.dart';
class XTestBanner extends StatelessWidget {
 const XTestBanner({super.key});
 @override Widget build(BuildContext context) => const SizedBox.shrink();
}
