import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'x_scan_ads.dart';
import '../localization/language.dart';
class XReward {
  static bool _busy=false;
  static Future<bool> earn() async {
    if(_busy || !XAdRuntime.enabled) return false;
    _busy=true;
    try{
      if(!await XAdRuntime.ready())return false;
      final loaded=Completer<RewardedAd?>();
      await RewardedAd.load(adUnitId: const String.fromEnvironment('XSCAN_REWARDED_ID',defaultValue:'ca-app-pub-3940256099942544/5224354917'),request:const AdRequest(),rewardedAdLoadCallback:RewardedAdLoadCallback(onAdLoaded:(ad){if(loaded.isCompleted){ad.dispose();}else{loaded.complete(ad);}},onAdFailedToLoad:(_){if(!loaded.isCompleted)loaded.complete(null);}));
      final ad=await loaded.future.timeout(const Duration(seconds:20),onTimeout:(){if(!loaded.isCompleted)loaded.complete(null);return null;});
      if(ad==null)return false;
      final done=Completer<bool>();var earned=false;
      ad.fullScreenContentCallback=FullScreenContentCallback(onAdDismissedFullScreenContent:(a){a.dispose();if(!done.isCompleted)done.complete(earned);},onAdFailedToShowFullScreenContent:(a,e){a.dispose();if(!done.isCompleted)done.complete(false);});
      try{await ad.show(onUserEarnedReward:(_,__)=>earned=true);}catch(_){ad.dispose();return false;}
      return await done.future;
    }catch(_){return false;}finally{_busy=false;}
  }
  static Future<bool?> choose(BuildContext context) async {
    final choice=await showModalBottomSheet<bool>(context:context,builder:(ctx)=>SafeArea(child:Column(mainAxisSize:MainAxisSize.min,children:[ListTile(leading:const Icon(Icons.download),title:Text(XLanguage.t(ctx,'Export now (with watermark)','Xuất ngay (có watermark)')),onTap:()=>Navigator.pop(ctx,false)),ListTile(leading:const Icon(Icons.play_circle),title:Text(XLanguage.t(ctx,'Watch one ad to export without watermark','Xem một quảng cáo để xuất không watermark')),onTap:()=>Navigator.pop(ctx,true))])));
    if(choice!=true)return choice;
    if(await earn())return true;
    if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(XLanguage.t(context,'Ad unavailable or reward not earned. Try again or export with watermark.','Chưa nhận được thưởng. Hãy thử lại hoặc xuất có watermark.'))));
    return null;
  }
}
