import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../kernel/x_kernel.dart';

class XAdRuntime {
  static Future<bool>? _init;
  static bool get enabled => !XKernel.instance.safeMode &&
      XKernel.instance.allowed(XModule.scan);
  static Future<bool> ready() async {
    if (!enabled) return false;
    return _init ??= _initialize();
  }
  static Future<bool> _initialize() async {
    try { await MobileAds.instance.initialize().timeout(const Duration(seconds: 15)); return true; }
    catch (_) { return false; }
  }
}
class XScanBanner extends StatefulWidget {
  const XScanBanner({super.key});
  @override State<XScanBanner> createState() => _BannerState();
}
class _BannerState extends State<XScanBanner> {
  BannerAd? _ad;
  bool loaded = false;
  @override void initState() { super.initState(); XKernel.instance.addListener(_changed); _load(); }
  void _changed() {
    if (!XAdRuntime.enabled) { _ad?.dispose(); _ad = null; if (mounted) setState(() => loaded=false); }
    else if (_ad == null) { _load(); }
  }
  Future<void> _load() async {
    if (!await XAdRuntime.ready() || !mounted || !XAdRuntime.enabled || _ad != null) return;
    final ad = BannerAd(adUnitId:'ca-app-pub-3940256099942544/6300978111', size:AdSize.banner, request:const AdRequest(), listener:BannerAdListener(
      onAdLoaded:(ad) { if (mounted && identical(ad,_ad)) setState(()=>loaded=true); },
      onAdFailedToLoad:(ad,error) { if (identical(ad,_ad)) { _ad=null; if(mounted) setState(()=>loaded=false); } ad.dispose(); },
    ));
    _ad=ad;
    try { await ad.load(); } catch (_) { if (identical(ad,_ad)) { _ad=null; ad.dispose(); } }
  }
  @override void dispose() { XKernel.instance.removeListener(_changed); _ad?.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => loaded && _ad != null && XAdRuntime.enabled
    ? Center(child:SizedBox(width:320,height:50,child:AdWidget(ad:_ad!))) : const SizedBox.shrink();
}
class XInterstitial {
  XInterstitial._();
  static final instance=XInterstitial._();
  final _random=Random();
  InterstitialAd? _ad;
  bool _loading=false, _showing=false;
  int _shown=0;
  DateTime? _last;
  void preload() async {
    if (_loading || _ad != null || _shown>=5 || !XAdRuntime.enabled) return;
    _loading=true;
    try {
      if (!await XAdRuntime.ready() || !XAdRuntime.enabled) { _loading=false; return; }
      await InterstitialAd.load(adUnitId:'ca-app-pub-3940256099942544/1033173712', request:const AdRequest(), adLoadCallback:InterstitialAdLoadCallback(
        onAdLoaded:(ad) { _loading=false; if(XAdRuntime.enabled) { _ad=ad; } else { ad.dispose(); } },
        onAdFailedToLoad:(error) { _loading=false; },
      ));
    } catch (_) { _loading=false; }
  }
  void safeTransition({bool premium=false}) {
    if(premium || !XAdRuntime.enabled || _showing || _shown>=5 || WidgetsBinding.instance.lifecycleState != AppLifecycleState.resumed) return;
    if(_last!=null && DateTime.now().difference(_last!)<const Duration(minutes:3)) return;
    final ad=_ad;
    if(ad==null) { preload(); return; }
    if(_random.nextDouble()>=0.2) return;
    _ad=null; _showing=true; _shown++; _last=DateTime.now();
    ad.fullScreenContentCallback=FullScreenContentCallback(
      onAdDismissedFullScreenContent:(ad) { ad.dispose(); _showing=false; preload(); },
      onAdFailedToShowFullScreenContent:(ad,error) { ad.dispose(); _showing=false; preload(); },
    );
    ad.show().catchError((Object e) { if(_showing) { _showing=false; ad.dispose(); } });
  }
}
