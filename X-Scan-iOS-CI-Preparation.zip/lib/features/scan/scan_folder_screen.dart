import '../cloud/x_manual_sync.dart';
import '../../core/export/x_image_export.dart';
import '../../core/ads/x_reward.dart';
import 'dart:io';
import '../../core/ads/x_scan_ads.dart';
import 'package:flutter/material.dart';
import 'scan_capture.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:pdf/widgets.dart' as pw;
import '../../core/export/x_pdf_exporter.dart';
import 'image_edit_screen.dart';
import 'scan_repository.dart';
import '../../core/localization/language.dart';

class ScanFolderScreen extends StatefulWidget {
  const ScanFolderScreen({super.key,required this.folder,this.autoStart=false});
  final ScanFolder folder;
  final bool autoStart;
  @override State<ScanFolderScreen> createState()=>_ScanFolderScreenState();
}
class _ScanFolderScreenState extends State<ScanFolderScreen> {
  List<File> files=[];
  final selected=<String>{};
  bool busy=false;
  bool reorderHint=true;
  @override void initState(){super.initState();refresh();
    if(widget.autoStart){WidgetsBinding.instance.addPostFrameCallback((_) {if(mounted)scan();});}
  }
  Future<void> refresh() async {
    final list=await ScanRepository.images(widget.folder);
    if(mounted)setState(()=>files=list);
  }
  Future<void> renameDocument() async {
    if (busy) return;
    final value = await showDialog<String>(context: context, builder: (ctx) {
      var draft = widget.folder.name;
      return AlertDialog(
        title: Text(XLanguage.t(ctx, 'Rename document', 'Đổi tên tài liệu')),
        content: TextFormField(initialValue: draft, autofocus: true,
          onChanged: (v) => draft = v,
          onFieldSubmitted: (v) => Navigator.pop(ctx, v.trim())),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(XLanguage.t(ctx, 'Cancel', 'Hủy'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, draft.trim()), child: Text(XLanguage.t(ctx, 'Save', 'Lưu'))),
        ],
      );
    });
    if (!mounted || value == null || value.isEmpty || value == widget.folder.name) return;
    final previous = widget.folder.name;
    setState(() => busy = true);
    try {
      widget.folder.name = value;
      await ScanRepository.save(widget.folder);
    } catch (_) {
      widget.folder.name = previous;
      if (mounted) showError(XLanguage.t(context, 'Unable to save document name.', 'Không lưu được tên tài liệu.'));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }
  Future<void> scan() async {
    if(busy)return;
    setState(()=>busy=true);
    try {
      final images=await ScanCapture.capture();
      for(final image in images){await ScanRepository.addImage(widget.folder,image);}
      await refresh();
    }on PlatformException catch(e){showError('Camera/Scanner (${e.code}): ${e.message} ${e.details ?? ""}');}
    catch(e){showError('Không quét được: $e');}
    finally{if(mounted)setState(()=>busy=false);}
  }
  void showError(String message){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(message)));}
  Future<void> add() async {
    final images=await ImagePicker().pickMultiImage();
    if(images.isEmpty)return;
    setState(()=>busy=true);
    try{for(final img in images){await ScanRepository.addImage(widget.folder,File(img.path));}await refresh();}
    catch(e){showError('Không thêm được ảnh: $e');}
    finally{if(mounted)setState(()=>busy=false);}
  }
  Future<void> export() async {
    final chosen=files.where((f)=>selected.contains(f.path)).toList();
    if(chosen.isEmpty){showError('Hãy chọn ít nhất một ảnh.');return;}
    setState(()=>busy=true);
    try{
      final doc=pw.Document(compress:true, title:'X-Scan PDF', creator:'X-Scan', author:'X-Scan');
      for(final file in chosen){
        final bytes=await file.readAsBytes();
        final image=pw.MemoryImage(bytes);
        doc.addPage(pw.Page(margin:pw.EdgeInsets.zero,
          build:(_)=>pw.Center(child:pw.Image(image,fit:pw.BoxFit.contain))));
      }
      final dir=Directory(p.join(widget.folder.path,'exports'));
      await dir.create(recursive:true);
      final out=File(p.join(dir.path,'X-Scan_${DateTime.now().millisecondsSinceEpoch}.pdf'));
      await out.writeAsBytes(await doc.save(),flush:true);
      if(mounted)await XPdfExporter.export(context,out);
    }catch(e){showError('Không xuất được PDF: $e');}
    finally{if(mounted)setState(()=>busy=false);}
  }
  Future<void> removeImage(File file) async {
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
      title:const Text('Xóa ảnh?'),content:const Text('Ảnh sẽ được chuyển vào thùng rác của thư mục.'),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Hủy')),
      FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Xóa'))]));
    if(ok!=true)return;
    final trash=Directory(p.join(widget.folder.path,'trash'));
    await trash.create(recursive:true);
    await file.rename(p.join(trash.path,'${DateTime.now().microsecondsSinceEpoch}_${p.basename(file.path)}'));
    selected.remove(file.path);await refresh();
  }
  Future<void> preview(File file) async {
    await Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>XImageEditor(file:file)));
    if(mounted) await refresh();
  }
  Future<void> deleteSelected() async {
    final chosen=files.where((f)=>selected.contains(f.path)).toList();
    if(chosen.isEmpty){showError('Hãy chọn ảnh cần xóa');return;}
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:Text('Xóa ${chosen.length} ảnh?'),content:const Text('Ảnh được chuyển vào thùng rác.'),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Hủy')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Xóa'))]));
    if(ok!=true)return;
    final trash=Directory(p.join(widget.folder.path,'trash'));await trash.create(recursive:true);
    for(final f in chosen){await f.rename(p.join(trash.path,'${DateTime.now().microsecondsSinceEpoch}_${p.basename(f.path)}'));}
    selected.clear();await refresh();
  }
  Future<void> editSelected() async {
    final chosen=files.where((f)=>selected.contains(f.path)).toList();
    if(chosen.length!=1){showError('Hãy chọn đúng một ảnh để chỉnh sửa');return;}
    await Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>XImageEditor(file:chosen.first)));
    await refresh();
  }
  Future<void> exportLongImage() => saveGallery(true);
  Future<void> saveGallery(bool long) async {
    if(busy)return;
    final chosen=files.where((f)=>selected.contains(f.path)).toList();
    if(chosen.isEmpty){showError('Hãy chọn ít nhất một ảnh.');return;}
    setState(()=>busy=true);
    try{final clean=await XReward.choose(context);if(clean==null)return;
      await XImageExport.save(chosen,long:long,clean:clean);showError('Đã lưu vào bộ sưu tập X-Scan');
    }catch(e){showError('Không lưu được ảnh: $e');}finally{if(mounted)setState(()=>busy=false);}
  }
  void move(int index,int direction){
    final to=index+direction;
    if(to<0||to>=files.length)return;
    setState((){final x=files.removeAt(index);files.insert(to,x);});
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:Text(widget.folder.name,maxLines:1,overflow:TextOverflow.ellipsis),actions:[
      IconButton(onPressed:busy?null:() async {await openManualSync(context,folderId:widget.folder.id);await refresh();},icon:const Icon(Icons.cloud_upload_outlined),tooltip:'Đồng bộ tài liệu này'),
      IconButton(onPressed:busy?null:renameDocument,icon:const Icon(Icons.edit_outlined),tooltip:XLanguage.t(context,'Rename document','Đổi tên tài liệu')),
    ]),
    body:Column(children:[

      Padding(padding:const EdgeInsets.all(8),child:Wrap(spacing:8,runSpacing:4,children:[
        FilledButton.icon(onPressed:busy?null:scan,icon:const Icon(Icons.document_scanner),label:const Text('Quét thêm')),

        OutlinedButton.icon(onPressed:busy?null:add,icon:const Icon(Icons.add_photo_alternate),label:const Text('Thêm ảnh')),
        OutlinedButton.icon(onPressed:busy?null:export,icon:const Icon(Icons.picture_as_pdf),label:const Text('PDF')),
        OutlinedButton.icon(onPressed:busy?null:()=>saveGallery(false),icon:const Icon(Icons.download),label:const Text('Lưu ảnh')),
        OutlinedButton.icon(onPressed:busy?null:exportLongImage,icon:const Icon(Icons.panorama_vertical),label:const Text('Ảnh dài')),
      ])),
      Padding(padding:const EdgeInsets.symmetric(horizontal:8),child:Row(children:[
        TextButton(onPressed:()=>setState((){if(selected.length==files.length){selected.clear();}else{selected.addAll(files.map((f)=>f.path));}}),child:Text(files.isNotEmpty&&selected.length==files.length?'Bỏ chọn':'Chọn tất cả')),
        Text('${selected.length} đã chọn'),const Spacer(),
        IconButton(tooltip:'Chỉnh sửa ảnh đã chọn',onPressed:selected.length==1?editSelected:null,icon:const Icon(Icons.tune)),
        IconButton(tooltip:'Xóa ảnh đã chọn',onPressed:selected.isNotEmpty?deleteSelected:null,icon:const Icon(Icons.delete_outline)),
      ])),
      if(busy)const LinearProgressIndicator(),
      if(reorderHint&&files.length>1)Padding(padding:const EdgeInsets.symmetric(horizontal:12),child:Row(children:[const Expanded(child:Text('Bấm mũi tên trên ảnh để đưa ảnh lên trước')),IconButton(onPressed:()=>setState(()=>reorderHint=false),icon:const Icon(Icons.close))])),
      Expanded(child:files.isEmpty?const Center(child:Text('Chưa có ảnh. Hãy quét hoặc thêm ảnh.')):
        GridView.builder(padding:const EdgeInsets.all(8),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,childAspectRatio:0.72,crossAxisSpacing:8,mainAxisSpacing:8),itemCount:files.length,
          itemBuilder:(ctx,i){final f=files[i];return Card(clipBehavior:Clip.antiAlias,child:Column(children:[
            Expanded(child:InkWell(onTap:()=>preview(f),child:SizedBox(width:double.infinity,child:Image.file(f,key:ValueKey('${f.path}_${f.lastModifiedSync().millisecondsSinceEpoch}'),fit:BoxFit.contain)))),
            Row(children:[const SizedBox(width:8),Text('${i+1}'),const Spacer(),
              Checkbox(value:selected.contains(f.path),onChanged:(v)=>setState((){if(v==true){selected.add(f.path);}else{selected.remove(f.path);}})),
              IconButton(tooltip:'Đưa ảnh lên trước',onPressed:i==0?null:(){move(i,-1);ScanRepository.savePageOrder(widget.folder,files);},icon:const Icon(Icons.arrow_upward,size:18)),const SizedBox(width:8)]),
          ]));})),
      if(!busy) const XScanBanner(),
    ]));
}
