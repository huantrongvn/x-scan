import 'dart:convert';
import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:pdfx/pdfx.dart';

class ScanFolder {
  ScanFolder({required this.id, required this.name, required this.path,
    this.pinned = false, this.starred = false, this.cover,
    required this.createdAt});
  final String id, path;
  String name;
  bool pinned, starred;
  String? cover;
  final DateTime createdAt;
  Directory get directory => Directory(path);
  Directory get pages => Directory(p.join(path, 'pages'));
  File get manifest => File(p.join(path, 'folder.json'));
  Map<String, dynamic> toJson() => {
    'id': id, 'name': name, 'pinned': pinned, 'starred': starred,
    'cover': cover, 'createdAt': createdAt.toIso8601String(),
  };
  static ScanFolder fromJson(String path, Map<String,dynamic> m) => ScanFolder(
    id: m['id'] as String, name: m['name'] as String, path: path,
    pinned: m['pinned'] == true, starred: m['starred'] == true,
    cover: m['cover'] as String?,
    createdAt: DateTime.tryParse(m['createdAt']?.toString() ?? '') ?? DateTime.now(),
  );
}

class ScanRepository {
  static Future<Directory> get root async {
    final base = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(base.path, 'checo', 'scan_folders'));
    await dir.create(recursive: true);
    return dir;
  }
  static Future<bool> isDeleted(String id) async {
    final dir = Directory(p.join((await root).parent.path, 'scan_states', id));
    if (!await dir.exists()) return false;
    final events = await dir.list().where((e) => e is File && RegExp(r'^\d+_(deleted|restored)\.json$').hasMatch(p.basename(e.path))).toList();
    events.sort((a,b) => p.basename(a.path).compareTo(p.basename(b.path)));
    return events.isNotEmpty && p.basename(events.last.path).endsWith('_deleted.json');
  }
  static Future<void> setDeleted(ScanFolder f, bool deleted) async {
    if (!RegExp(r'^\d+$').hasMatch(f.id)) throw StateError('ID không hợp lệ');
    final dir = Directory(p.join((await root).parent.path, 'scan_states', f.id));
    await dir.create(recursive:true);
    final stamp = DateTime.now().toUtc().microsecondsSinceEpoch;
    final state = deleted ? 'deleted' : 'restored';
    final target = File(p.join(dir.path, '${stamp}_$state.json'));
    final temp = File('${target.path}.tmp');
    await temp.writeAsString(jsonEncode({'id':f.id,'state':state,'at':stamp}),flush:true);
    await temp.rename(target.path);
  }
  static Future<void> _atomicText(File target, String text) async {
    final temp = File('${target.path}.${DateTime.now().microsecondsSinceEpoch}.tmp');
    try {
      await temp.writeAsString(text, flush: true);
      await temp.rename(target.path);
    } finally {
      if (await temp.exists()) await temp.delete();
    }
  }
  static Future<void> save(ScanFolder f) async {
    await _atomicText(f.manifest, jsonEncode(f.toJson()));
  }
  static Future<List<ScanFolder>> folders({bool deleted = false}) async {
    final dir = await root;
    final found = <ScanFolder>[];
    await for (final item in dir.list()) {
      if (item is! Directory || p.basename(item.path).startsWith('.')) continue;
      if (await isDeleted(p.basename(item.path)) != deleted) continue;
      final manifest = File(p.join(item.path, 'folder.json'));
      if (!await manifest.exists()) continue;
      try { found.add(ScanFolder.fromJson(item.path,
        jsonDecode(await manifest.readAsString()) as Map<String,dynamic>)); }
      catch (_) { /* Keep damaged folder untouched for recovery. */ }
    }
    found.sort((a,b) {
      if (a.pinned != b.pinned) return a.pinned ? -1 : 1;
      return b.createdAt.compareTo(a.createdAt);
    });
    return found;
  }
  static Future<String> _device() async {
    try {
      final info = DeviceInfoPlugin();
      String value = 'Device';
      if (Platform.isAndroid) value = (await info.androidInfo).model;
      if (Platform.isIOS) value = (await info.iosInfo).name;
      value = value.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '');
      return value.isEmpty ? 'Device' : value;
    } catch (_) { return 'Device'; }
  }
  static Future<ScanFolder> create() async {
    final now = DateTime.now();
    final d = '${now.year}${now.month.toString().padLeft(2,'0')}${now.day.toString().padLeft(2,'0')}';
    final t = '${now.hour.toString().padLeft(2,'0')}${now.minute.toString().padLeft(2,'0')}';
    final name = 'X-Scan-${await _device()}-$d-$t';
    final base = await root;
    var id = '${now.microsecondsSinceEpoch}';
    var dir = Directory(p.join(base.path,id));
    while (await dir.exists()) { id = '${DateTime.now().microsecondsSinceEpoch}'; dir = Directory(p.join(base.path,id)); }
    await dir.create(recursive: true);
    final folder = ScanFolder(id:id,name:name,path:dir.path,createdAt:now);
    await folder.pages.create(recursive:true);
    await save(folder);
    return folder;
  }
  static Future<ScanFolder> createWithImages(List<File> sources) async {
    if(sources.isEmpty) throw StateError('Không có ảnh');
    final base=await root;
    final now=DateTime.now();
    final id='${now.microsecondsSinceEpoch}';
    // Stage within the same filesystem before publishing the manifest.
    final pending=Directory(p.join(base.path,'.pending_$id'));
    final target=Directory(p.join(base.path,id));
    try {
      final f=ScanFolder(id:id,name:'X-Scan-${await _device()}-${now.toIso8601String().substring(0,16).replaceAll(":", "-")}',path:pending.path,createdAt:now);
      await f.pages.create(recursive:true);
      for(final source in sources){await addImage(f,source);}
      await save(f);
      await pending.rename(target.path);
      final committed=ScanFolder(id:id,name:f.name,path:target.path,createdAt:now);

      return committed;
    } finally {
      if(await pending.exists())await pending.delete(recursive:true);
    }
  }
  static Future<List<File>> images(ScanFolder f) async {
    if (!await f.pages.exists()) return [];
    final list = await f.pages.list().where((e) => e is File &&
      ['.jpg','.jpeg','.png'].contains(p.extension(e.path).toLowerCase())).cast<File>().toList();
    list.sort((a,b) => p.basename(a.path).compareTo(p.basename(b.path)));
    final orderFile=File(p.join(f.path,'page_order.json'));
    if(await orderFile.exists()){
      try{
        final names=(jsonDecode(await orderFile.readAsString()) as List).cast<String>();
        final rank={for(var i=0;i<names.length;i++) names[i]:i};
        list.sort((a,b){
          final ra=rank[p.basename(a.path)]??999999;
          final rb=rank[p.basename(b.path)]??999999;
          return ra!=rb?ra.compareTo(rb):p.basename(a.path).compareTo(p.basename(b.path));
        });
      }catch(_){/* preserve files if metadata is damaged */}
    }
    return list;
  }
  static Future<void> savePageOrder(ScanFolder f,List<File> files) async {
    final target=File(p.join(f.path,'page_order.json'));
    await _atomicText(target, jsonEncode(files.map((f)=>p.basename(f.path)).toList()));
  }
  static Future<File?> thumbnail(ScanFolder f) async {
    if (f.cover != null) {
      final cover = File(p.join(f.path, f.cover!));
      if (await cover.exists()) return cover;
    }
    final items = await images(f);
    return items.isEmpty ? null : items.first;
  }
  static Future<void> setCover(ScanFolder f, File file) async {
    final dest = File(p.join(f.path,'cover${p.extension(file.path).toLowerCase()}'));
    await file.copy(dest.path);
    f.cover = p.basename(dest.path);
    await save(f);
  }
  static Future<void> addImage(ScanFolder f, File source) async {
    final target = File(p.join(f.pages.path,
      '${DateTime.now().microsecondsSinceEpoch}${p.extension(source.path).toLowerCase()}'));
    await source.copy(target.path);
  }
  static Future<void> addPdf(ScanFolder f, File source) async {
    final originalDir = Directory(p.join(f.path,'original_pdfs'));
    await originalDir.create(recursive:true);
    final original = File(p.join(originalDir.path,
      '${DateTime.now().microsecondsSinceEpoch}.pdf'));
    await source.copy(original.path);
    final pdf = await PdfDocument.openFile(original.path);
    try {
      for (var i=1;i<=pdf.pagesCount;i++) {
        final page = await pdf.getPage(i);
        try {
          final scale = 1600 / (page.width > page.height ? page.width : page.height);
          final img = await page.render(width:page.width*scale,
            height:page.height*scale,format:PdfPageImageFormat.png);
          if (img == null) throw StateError('Không đọc được trang PDF $i');
          final dest = File(p.join(f.pages.path,
            '${DateTime.now().microsecondsSinceEpoch}_${i.toString().padLeft(4,'0')}.png'));
          await dest.writeAsBytes(img.bytes,flush:true);
        } finally { await page.close(); }
      }
    } finally { await pdf.close(); }
  }
  /// Non-destructive legacy migration: copy old PDFs into session folders.
  /// Marker is written only after all imports succeed; originals stay in place.
  static Future<void> migrateLegacy() async {
    final base = await getApplicationDocumentsDirectory();
    final legacy = Directory(p.join(base.path,'checo','scan'));
    if (!await legacy.exists()) return;
    final marker = File(p.join((await root).path,'.legacy_migrated_v1'));
    if (await marker.exists()) return;
    final pdfs = await legacy.list().where((x) => x is File &&
      p.extension(x.path).toLowerCase()=='.pdf').cast<File>().toList();
    for (final pdf in pdfs) {
      final f = await create();
      f.name = p.basenameWithoutExtension(pdf.path);
      await save(f);
      await addPdf(f,pdf);
    }
    await marker.writeAsString(DateTime.now().toIso8601String());
  }
}
