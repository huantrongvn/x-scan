import 'dart:io';
import '../../core/ads/x_scan_ads.dart';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../../core/image/x_image_core.dart';
class XImageEditor extends StatefulWidget {
  const XImageEditor({super.key,required this.file});
  final File file;
  @override State<XImageEditor> createState()=>_EditorState();
}
class _EditorState extends State<XImageEditor> {
  static const modes=<String,String>{'color':'Gốc','auto':'Tự động','bw':'Đen trắng','gray':'Xám','text':'Rõ chữ','vivid':'Màu đẹp','sharp':'Tăng nét','warm':'Ấm','cool':'Lạnh','sepia':'Sepia','vintage':'Vintage','negative':'Âm bản'};
  String mode='color';int rotation=0,brightness=0,contrast=100;
  Uint8List? source,preview;bool busy=false;int serial=0;
  XImageEdits get edits=>XImageEdits(mode:mode,rotation:rotation,brightness:brightness,contrast:contrast);
  @override void initState(){super.initState();load();}
  Future<void> load() async {source=await widget.file.readAsBytes();if(mounted)update();}
  Future<void> update() async {
    final bytes=source;if(bytes==null)return;final id=++serial;
    try{final result=await XImageCore.preview(bytes,edits);if(mounted&&id==serial)setState(()=>preview=result);}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Lỗi xem trước: $e')));}
  }
  void change(VoidCallback action){setState(action);update();}
  Future<void> save() async {
    if(busy)return;
    if(mode=='color'&&rotation==0&&brightness==0&&contrast==100){Navigator.pop(context,false);return;}
    setState(()=>busy=true);
    try{
      final originals=Directory('${widget.file.parent.path}/originals');await originals.create(recursive:true);
      final backup=File('${originals.path}/${widget.file.uri.pathSegments.last}');
      if(!await backup.exists())await widget.file.copy(backup.path);
      final temp=File('${widget.file.path}.xscan.tmp.jpg');
      await XImageCore.render(widget.file,temp,edits);
      await temp.rename(widget.file.path);
      if(mounted)Navigator.pop(context,true);
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Không lưu được: $e')));}
    finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Chỉnh sửa ảnh'),actions:[TextButton(onPressed:busy?null:save,child:const Text('Lưu'))]),
    body:Column(children:[
      Expanded(child:Container(color:Theme.of(context).colorScheme.surfaceContainerLow,alignment:Alignment.center,
        child:preview==null?const CircularProgressIndicator():InteractiveViewer(minScale:0.5,maxScale:5,child:Image.memory(preview!,fit:BoxFit.contain,gaplessPlayback:true)))),
      const Padding(padding:EdgeInsets.only(top:8),child:Text('Chạm hiệu ứng để xem trước · Vuốt ngang để xem thêm')),
      SizedBox(height:92,child:ListView(scrollDirection:Axis.horizontal,padding:const EdgeInsets.all(8),children:modes.entries.map((entry)=>Padding(padding:const EdgeInsets.only(right:8),child:ChoiceChip(label:Text(entry.value),selected:mode==entry.key,onSelected:busy?null:(_)=>change(()=>mode=entry.key)))).toList())),
      Row(children:[IconButton(onPressed:busy?null:()=>change(()=>rotation=(rotation+90)%360),icon:const Icon(Icons.rotate_right),tooltip:'Xoay'),const SizedBox(width:8),const Text('Sáng'),Expanded(child:Slider(value:brightness.toDouble(),min:-100,max:100,onChanged:busy?null:(v)=>change(()=>brightness=v.round())))]),
      Row(children:[const SizedBox(width:56),const Text('Tương phản'),Expanded(child:Slider(value:contrast.toDouble(),min:0,max:200,onChanged:busy?null:(v)=>change(()=>contrast=v.round())))]),
      if(busy)const LinearProgressIndicator(),
      if(!busy) const XScanBanner(),
    ]));
}
