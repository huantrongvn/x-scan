import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:pdfx/pdfx.dart';

class XOcrScreen extends StatefulWidget {
  const XOcrScreen({super.key, required this.file});
  final File file;

  @override
  State<XOcrScreen> createState() => _XOcrScreenState();
}

class _XOcrScreenState extends State<XOcrScreen> {
  bool _busy = false;
  String? _error;
  String _text = '';
  int _done = 0;
  int _total = 0;

  String get _sidecarPath => '${widget.file.path}.ocr.json';

  @override
  void initState() {
    super.initState();
    _loadSaved();
  }

  Future<void> _loadSaved() async {
    try {
      final sidecar = File(_sidecarPath);
      if (!await sidecar.exists()) return;
      final data =
          jsonDecode(await sidecar.readAsString()) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() => _text = (data['text'] ?? '').toString());
    } catch (e) {
      if (mounted) setState(() => _error = 'Khong doc duoc ket qua OCR cu: $e');
    }
  }

  Future<void> _recognize() async {
    if (_busy) return;
    if (!Platform.isAndroid && !Platform.isIOS) {
      setState(() => _error = 'OCR chi ho tro Android/iOS.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
      _done = 0;
      _total = 0;
    });
    PdfDocument? document;
    final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
    final chunks = <String>[];
    try {
      document = await PdfDocument.openFile(widget.file.path);
      final count = document.pagesCount;
      if (mounted) setState(() => _total = count);
      for (var i = 1; i <= count; i++) {
        final page = await document.getPage(i);
        File? temp;
        try {
          // Render one page at a time; cap longest side to 2200px.
          final scale =
              2200.0 / (page.width > page.height ? page.width : page.height);
          final rendered = await page.render(
            width: page.width * scale,
            height: page.height * scale,
            format: PdfPageImageFormat.png,
          );
          if (rendered == null) throw StateError('Khong render duoc trang $i');
          temp = File(
            '${Directory.systemTemp.path}${Platform.pathSeparator}xscan_ocr_${DateTime.now().microsecondsSinceEpoch}_$i.png',
          );
          await temp.writeAsBytes(rendered.bytes, flush: true);
          final recognized = await recognizer.processImage(
            InputImage.fromFilePath(temp.path),
          );
          chunks.add('--- Trang $i ---\n${recognized.text}');
        } finally {
          await page.close();
          if (temp != null && await temp.exists()) await temp.delete();
        }
        if (mounted) setState(() => _done = i);
      }
      final output = chunks.join('\n\n');
      await File(_sidecarPath).writeAsString(
        jsonEncode({
          'schemaVersion': 1,
          'source': widget.file.uri.pathSegments.last,
          'engine': 'google_mlkit_latin',
          'createdAt': DateTime.now().toUtc().toIso8601String(),
          'pages': count,
          'text': output,
        }),
        flush: true,
      );
      if (mounted) setState(() => _text = output);
    } catch (e) {
      if (mounted) setState(() => _error = 'OCR that bai: $e');
    } finally {
      await document?.close();
      await recognizer.close();
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('X-Scan OCR'),
        actions: [
          IconButton(
            tooltip: 'Sao chep van ban',
            onPressed: _text.isEmpty
                ? null
                : () async {
                    await Clipboard.setData(ClipboardData(text: _text));
                    if (context.mounted)
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Da sao chep van ban')),
                      );
                  },
            icon: const Icon(Icons.copy_outlined),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            FilledButton.icon(
              onPressed: _busy ? null : _recognize,
              icon: const Icon(Icons.document_scanner_outlined),
              label: Text(
                _busy
                    ? 'Dang OCR $_done/$_total trang'
                    : 'Nhan dang chu trong PDF',
              ),
            ),
            if (_busy)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: LinearProgressIndicator(),
              ),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text(
                  _error!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error),
                ),
              ),
            const SizedBox(height: 12),
            Expanded(
              child: _text.isEmpty
                  ? const Center(
                      child: Text(
                        'Bam Nhan dang chu de xu ly offline. Ket qua duoc luu canh PDF.',
                      ),
                    )
                  : SingleChildScrollView(child: SelectableText(_text)),
            ),
          ],
        ),
      ),
    );
  }
}
