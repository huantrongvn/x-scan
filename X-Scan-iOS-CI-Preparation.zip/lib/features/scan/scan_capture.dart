import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter_doc_scanner/flutter_doc_scanner.dart';


class ScanCapture {
  static bool _running = false;
  static const _channel = MethodChannel('checo/scan_uri');
  static Future<List<File>> capture() async {
    if (_running) throw StateError('Một phiên camera đang chạy');
    _running = true;
    try {
      final result = await FlutterDocScanner().getScannedDocumentAsImages(page: 20);
      if (result == null) return [];
      final paths = result.images;
      final files = <File>[];
      for (final item in paths) {
        final raw = item;
        if (raw.isEmpty) throw StateError('Thiếu đường dẫn ảnh');
        final uri = Uri.tryParse(raw);
        final path = uri?.scheme == 'content' ? await _channel.invokeMethod<String>('copyImage', raw) : uri?.scheme == 'file' ? uri!.toFilePath() : raw;
        if (path == null) throw StateError('Không đọc được ảnh');
        final file = File(path);
        if (!await file.exists() || await file.length() == 0) throw StateError('Ảnh không hợp lệ');
        files.add(file);
      }
      return files;
    } finally { _running = false; }
  }
}
