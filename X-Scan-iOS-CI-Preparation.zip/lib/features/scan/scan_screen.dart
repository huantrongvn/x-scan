import '../cloud/x_manual_sync.dart';
import 'scan_capture.dart';
import 'dart:io';
import '../../core/ads/x_scan_ads.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'scan_repository.dart';
import 'scan_folder_screen.dart';

class ScanScreen extends StatefulWidget {
  static bool activityBusy = false;
  const ScanScreen({super.key});
  @override State<ScanScreen> createState()=>_ScanScreenState();
}
class _ScanScreenState extends State<ScanScreen> {
  List<ScanFolder> folders=[];
  bool busy=false;
  @override void initState(){super.initState();refresh();XInterstitial.instance.preload();}
  Future<void> refresh() async {
    try {
      await ScanRepository.migrateLegacy();
      final data=await ScanRepository.folders();
      if(mounted)setState(()=>folders=data);
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Không đọc được thư viện: $e')));}
  }
  Future<void> create() async {
    if(busy)return;
    ScanScreen.activityBusy = true;
    setState(()=>busy=true);
    try {
      final images=await ScanCapture.capture();
      if(images.isEmpty)return;
      final folder=await ScanRepository.createWithImages(images);
      if(!mounted)return;
      await Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>ScanFolderScreen(folder:folder)));
      await refresh();
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(duration:const Duration(seconds:12),content:Text('Lỗi quét: $e')));}
    finally{ScanScreen.activityBusy = false; if(mounted)setState(()=>busy=false); }
  }
  Future<void> rename(ScanFolder f) async {
    final ctrl=TextEditingController(text:f.name);
    final value=await showDialog<String>(context:context,builder:(ctx)=>AlertDialog(
      title:const Text('Đổi tên thư mục'),content:TextField(controller:ctrl,autofocus:true),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Hủy')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,ctrl.text.trim()),child:const Text('Lưu'))]));
    ctrl.dispose();
    if(value==null||value.isEmpty)return;
    f.name=value;await ScanRepository.save(f);await refresh();
  }
  Future<void> changeCover(ScanFolder f) async {
    final file=await ImagePicker().pickImage(source:ImageSource.gallery);
    if(file==null)return;
    await ScanRepository.setCover(f,File(file.path));await refresh();
  }
  Future<void> deleteFolder(ScanFolder f) async {
    final yes = await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
      title:const Text('Xóa thư mục?'),content:Text('Chuyển ${f.name} và toàn bộ tài liệu vào thùng rác.'),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Hủy')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Xóa'))]));
    if(yes!=true)return;
    try { await ScanRepository.setDeleted(f,true); await refresh(); }
    catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Lỗi xóa: $e')));}
  }
  Future<void> openTrash() async {
    await Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>const _FolderTrash()));
    await refresh();
  }
  Future<void> action(ScanFolder f,String a) async {
    if(a=='sync'){await openManualSync(context,folderId:f.id);await refresh();return;}
    if(a=='delete')return deleteFolder(f);
    if(a=='rename')return rename(f);
    if(a=='cover')return changeCover(f);
    if(a=='pin')f.pinned=!f.pinned;
    if(a=='star')f.starred=!f.starred;
    await ScanRepository.save(f);await refresh();
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('X-Scan'),actions:[IconButton(onPressed:busy?null:() async {await openManualSync(context);await refresh();},icon:const Icon(Icons.cloud_upload_outlined),tooltip:'Đồng bộ Cloud'),IconButton(onPressed:busy?null:openTrash,icon:const Icon(Icons.delete_outline),tooltip:'Thùng rác'),IconButton(onPressed:refresh,icon:const Icon(Icons.refresh))]),
    body:Column(children:[

      Padding(padding:const EdgeInsets.all(16),child:SizedBox(width:double.infinity,
        child:FilledButton.icon(onPressed:busy?null:()=>create(),
          icon:const Icon(Icons.document_scanner_outlined),label:const Text('Bắt đầu quét tài liệu mới')))),

      const Padding(padding:EdgeInsets.fromLTRB(16,0,16,8),child:Align(alignment:Alignment.centerLeft,
        child:Text('Thư viện đã quét',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)))),
      Expanded(child:folders.isEmpty?const Center(child:Text('Chưa có thư mục scan.')):
        ListView.builder(itemCount:folders.length,itemBuilder:(ctx,i){
          final f=folders[i];
          return FutureBuilder<File?>(future:ScanRepository.thumbnail(f),builder:(ctx,snap)=>
            ListTile(
              leading:SizedBox(width:58,height:72,child:snap.hasData&&snap.data!=null?
                Image.file(snap.data!,fit:BoxFit.cover):const Icon(Icons.folder_outlined,size:38)),
              title:Text(f.name,maxLines:2,overflow:TextOverflow.ellipsis),
              subtitle:Row(children:[if(f.pinned)const Icon(Icons.push_pin,size:16),
                if(f.starred)const Icon(Icons.star,size:16),Text('  ${p.basename(f.path)}')]),
              onTap:()async{await Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>ScanFolderScreen(folder:f)));await refresh();},
              trailing:PopupMenuButton<String>(onSelected:(v)=>action(f,v),itemBuilder:(_)=>[
                const PopupMenuItem(value:'sync',child:Text('Đồng bộ tài liệu này')),
                const PopupMenuItem(value:'rename',child:Text('Đổi tên')),
                PopupMenuItem(value:'pin',child:Text(f.pinned?'Bỏ ghim':'Ghim lên đầu')),
                PopupMenuItem(value:'star',child:Text(f.starred?'Bỏ yêu thích':'Yêu thích')),
                const PopupMenuItem(value:'cover',child:Text('Thay thumbnail')),
                const PopupMenuItem(value:'delete',child:Text('Xóa thư mục')),
              ]),
            ));
        })),
      if(!busy) const XScanBanner(),
    ]));
}

class _FolderTrash extends StatefulWidget {
  const _FolderTrash();
  @override State<_FolderTrash> createState()=>_FolderTrashState();
}
class _FolderTrashState extends State<_FolderTrash> {
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Thùng rác thư mục')),
    body:FutureBuilder<List<ScanFolder>>(future:ScanRepository.folders(deleted:true),builder:(context,snapshot){
      if(snapshot.hasError)return Center(child:Text('${snapshot.error}'));
      if(!snapshot.hasData)return const Center(child:CircularProgressIndicator());
      final items=snapshot.data!;
      if(items.isEmpty)return const Center(child:Text('Thùng rác trống'));
      return ListView(children:[for(final f in items) ListTile(title:Text(f.name),trailing:TextButton(child:const Text('Khôi phục'),onPressed:()async{
        try {await ScanRepository.setDeleted(f,false);if(mounted)setState((){});}
        catch(e){if(mounted)ScaffoldMessenger.of(this.context).showSnackBar(SnackBar(content:Text('$e')));}
      }))]);
    }));
}
