import 'dart:io';

import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/cloud/x_publish_session.dart';
import 'x_publish_widgets.dart';

import '../../core/auth/x_google_auth.dart';
import '../../core/cloud/x_drive_client.dart';
import '../../core/cloud/x_share_service.dart';

class XShareScreen extends StatefulWidget {
  const XShareScreen({super.key});
  @override
  State<XShareScreen> createState() => _XShareScreenState();
}

class _XShareScreenState extends State<XShareScreen> {
  final _picker = ImagePicker();
  final _drive = XDriveClient();
  late final _service = XShareService(_drive);
  final Map<String, int> _sizes = {};
  List<XFile> _files = [];
  String _expiry = 'never';
  bool _busy = false;
  int _done = 0, _percent = 0, _bytes = 0, _total = 0;
  String _stage = '';
  XPublishSession? _session;
  String? _link;
  String? _message;

  late final Future<void> _cleanup;
  @override
  void initState() {
    super.initState();
    _cleanup = _cleanupWhenOpened();
  }

  Future<GoogleSignInAccount> _account() async =>
      await XGoogleAuth.instance.restore() ??
      await XGoogleAuth.instance.signIn() ??
      (throw StateError('Cần đăng nhập Google'));

  Future<void> _cleanupWhenOpened() async {
    try {
      final account = await XGoogleAuth.instance.restore();
      if (account != null) await _service.cleanup(account);
    } catch (_) {
      /* retry next time */
    }
  }

  Future<void> _pick() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final picked = await _picker.pickMultiImage();
      final sizes = <String, int>{};
      for (final f in picked) {
        sizes[f.path] = await f.length();
      }
      if (!mounted || picked.isEmpty) return;
      setState(() {
        _files = {
          for (final f in [..._files, ...picked]) f.path: f,
        }.values.toList();
        _sizes.addAll(sizes);
        _link = null; _session = null; _percent = 0;
        _message = null;
      });
    } catch (_) {
      if (mounted)
        setState(() => _message = 'Không thể chọn ảnh. Vui lòng thử lại.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _shareLink() async {
    final link = _link;
    if (link == null || !mounted) return;
    try {
      await shareXLink(context, link);
    } catch (_) {
      if (mounted)
        setState(
          () => _message =
              'Không mở được menu chia sẻ. Bạn có thể sao chép liên kết.',
        );
    }
  }

  Future<void> _publish() async {
    if (_files.isEmpty || _busy) return;
    if (_link != null) {
      await _shareLink();
      return;
    }
    setState(() {
      _busy = true;
      _message = null;
      if (_session == null) { _done = 0; _percent = 0; _bytes = 0; _total = 0; }
    });
    try {
      await _cleanup;
      final account = await _account();
      _session ??= XPublishSession(_drive, _files.map((f) => File(f.path)).toList(), 'share', _expiry);
      final link = await _session!.run(account, (percent, done, bytes, total, stage) {
        if (mounted) setState(() { _percent = percent; _done = done; _bytes = bytes; _total = total; _stage = stage; });
      });
      if (!mounted) return;
      setState(() => _link = link);
      await _shareLink();
    } catch (e) {
      if (mounted)
        setState(
          () => _message = publishError(e),
        );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _drive.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bytes = _files.fold<int>(0, (sum, f) => sum + (_sizes[f.path] ?? 0));
    return Scaffold(
      appBar: AppBar(title: const Text('X-Share')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            'Chia sẻ ảnh chất lượng gốc. Người nhận không cần cài X-Scan.',
          ),
          const SizedBox(height: 20),
          Text(
            'Bước 1. Chọn ảnh',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          OutlinedButton.icon(
            onPressed: _busy ? null : _pick,
            icon: const Icon(Icons.photo_library_outlined),
            label: Text(_files.isEmpty ? 'Chọn ảnh' : 'Thêm ảnh'),
          ),
          if (_files.isNotEmpty)
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                crossAxisSpacing: 6,
                mainAxisSpacing: 6,
              ),
              itemCount: _files.length,
              itemBuilder: (context, i) => Stack(
                fit: StackFit.expand,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.file(
                      File(_files[i].path),
                      fit: BoxFit.cover,
                      cacheWidth: 240,
                      errorBuilder: (_, e, st) =>
                          const Icon(Icons.broken_image),
                    ),
                  ),
                  Positioned(
                    top: 0,
                    right: 0,
                    child: IconButton.filledTonal(
                      visualDensity: VisualDensity.compact,
                      iconSize: 18,
                      onPressed: _busy
                          ? null
                          : () => setState(() {
                              _sizes.remove(_files[i].path);
                              _files.removeAt(i);
                              _link = null; _session = null; _percent = 0;
                              _message = null;
                            }),
                      icon: const Icon(Icons.close),
                      tooltip: 'Bỏ ảnh',
                    ),
                  ),
                ],
              ),
            ),
          Text(
            'Đã chọn ${_files.length} ảnh · ${(bytes / 1048576).toStringAsFixed(1)} MB',
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            initialValue: _expiry,
            decoration: const InputDecoration(
              labelText: 'Tự động xóa ảnh chia sẻ',
            ),
            items: const [
              DropdownMenuItem(
                value: 'never',
                child: Text('Không xóa (mặc định)'),
              ),
              DropdownMenuItem(value: '1h', child: Text('Sau 1 giờ')),
              DropdownMenuItem(value: '12h', child: Text('Sau 12 giờ')),
            ],
            onChanged: _busy
                ? null
                : (v) => setState(() {
                    _expiry = v ?? 'never';
                    _link = null; _session = null; _percent = 0;
                  }),
          ),
          if (_expiry != 'never')
            const Padding(
              padding: EdgeInsets.only(top: 8),
              child: Text(
                'Ảnh được dọn dẹp khi ứng dụng mở lại và có Internet. Link Drive có thể còn hoạt động cho đến khi xóa thành công.',
              ),
            ),
          const SizedBox(height: 20),
          const Divider(),
          Text(
            'Bước 2. Gửi cho bạn bè',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          if (_link == null) FilledButton.icon(
            onPressed: _busy || _files.isEmpty ? null : _publish,
            icon: const Icon(Icons.share_outlined),
            label: Text(_busy ? 'Đang chuẩn bị...' : _session != null ? 'Thử lại' : 'Chia sẻ ngay'),
          ),
          if (_busy || _percent > 0) XProgress(percent: _percent, done: _done, count: _files.length, bytes: _bytes, total: _total, stage: _stage),
          if (_message != null) Text(_message!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          if (_link != null) XLinkActions(link: _link!, onShare: _shareLink),
        ],
      ),
    );
  }
}
