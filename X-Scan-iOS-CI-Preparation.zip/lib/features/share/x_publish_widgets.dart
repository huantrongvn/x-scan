import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

Future<void> shareXLink(BuildContext context, String link) async {
  final box = context.findRenderObject() as RenderBox?;
  await SharePlus.instance.share(ShareParams(text: link, sharePositionOrigin: box == null ? null : box.localToGlobal(Offset.zero) & box.size));
}
class XLinkActions extends StatelessWidget {
  const XLinkActions({super.key, required this.link, required this.onShare});
  final String link;
  final VoidCallback onShare;
  @override Widget build(BuildContext context) => Column(children: [
    SelectableText(link),
    Row(children: [
      Expanded(child: OutlinedButton.icon(onPressed: () async { await Clipboard.setData(ClipboardData(text: link)); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã sao chép liên kết'))); }, icon: const Icon(Icons.copy), label: const Text('Sao chép'))),
      const SizedBox(width: 8),
      Expanded(child: FilledButton.icon(onPressed: onShare, icon: const Icon(Icons.share), label: const Text('Chia sẻ'))),
    ])
  ]);
}
class XProgress extends StatelessWidget {
  const XProgress({super.key, required this.percent, required this.done, required this.count, required this.bytes, required this.total, required this.stage});
  final int percent, done, count, bytes, total;
  final String stage;
  @override Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [Expanded(child: Text(stage)), Text('$percent%')]),
    LinearProgressIndicator(value: percent / 100),
    Text('$done/$count tệp · ${(bytes/1048576).toStringAsFixed(1)}/${(total/1048576).toStringAsFixed(1)} MB'),
  ]);
}
