import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../../core/auth/x_google_auth.dart';
import '../../core/cloud/x_drive_client.dart';
import '../../core/cloud/x_transfer_service.dart';
import '../../core/cloud/x_publish_session.dart';
import '../share/x_publish_widgets.dart';

class XTransferScreen extends StatefulWidget {
  const XTransferScreen({super.key});
  @override State<XTransferScreen> createState() => _XTransferScreenState();
}
class _XTransferScreenState extends State<XTransferScreen> {
  final drive = XDriveClient();
  late final service = XTransferService(drive);
  List<File> files = [];
  bool busy = false;
  String? link, error;
  XPublishSession? session;
  int percent = 0, done = 0, bytes = 0, total = 0;
  String stage = '';
  late final Future<void> cleanup;
  @override void initState() { super.initState(); cleanup = _cleanup(); }
  Future<void> _cleanup() async { try { final a = await XGoogleAuth.instance.restore(); if (a != null) await service.cleanup(a); } catch (_) {} }
  Future<void> _pick() async {
    if (busy) return;
    setState(() => busy = true);
    try {
      // file_picker 12: preserve explicit multi-selection until API migration is verified.
      // ignore: deprecated_member_use
      final selection = await FilePicker.pickFiles(type: FileType.custom, allowMultiple: true, allowedExtensions: ['jpg','jpeg','png','webp','pdf']);
      if (!mounted || selection.isEmpty) return;
      final picked = selection.map((e) => e.path).whereType<String>().map(File.new).toList();
      final sizes = await Future.wait(picked.map((f) => f.length()));
      if (!mounted) return;
      setState(() { files = picked; session = null; link = null; error = null; percent = 0; done = 0; bytes = 0; total = sizes.fold<int>(0,(a,b)=>a+b); });
    } catch (_) { if (mounted) setState(() => error = 'Không thể chọn tệp.'); }
    finally { if (mounted) setState(() => busy = false); }
  }
  Future<void> _share() async { if (link == null || !mounted) return; try { await shareXLink(context, link!); } catch (_) { if (mounted) setState(() => error = 'Không mở được menu chia sẻ. Hãy sao chép liên kết.'); } }
  Future<void> _send() async {
    if (busy || files.isEmpty) return;
    setState(() { busy = true; error = null; });
    try {
      await cleanup;
      final account = await XGoogleAuth.instance.restore() ?? await XGoogleAuth.instance.signIn() ?? (throw StateError('Cần đăng nhập Google'));
      session ??= XPublishSession(drive, List.of(files), 'transfer', '1h');
      final value = await session!.run(account, (p,d,b,t,s) { if (mounted) setState(() { percent=p; done=d; bytes=b; total=t; stage=s; }); });
      if (!mounted) return;
      setState(() => link = value);
      await _share();
    } catch (e) { if (mounted) setState(() => error = publishError(e)); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override void dispose() { drive.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Gửi đến máy tính')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('Chọn ảnh hoặc PDF. Mở liên kết X-Scan trên máy tính để xem và tải xuống mà không cần đăng nhập.'),
      const SizedBox(height: 16),
      OutlinedButton.icon(onPressed: busy ? null : _pick, icon: const Icon(Icons.attach_file), label: const Text('Chọn ảnh / PDF')),
      Text('Đã chọn ${files.length} tệp · ${(total/1048576).toStringAsFixed(1)} MB'),
      const SizedBox(height: 16),
      if (link == null) FilledButton.icon(onPressed: busy || files.isEmpty ? null : _send, icon: const Icon(Icons.upload_file), label: Text(busy ? 'Đang xử lý...' : session != null ? 'Thử lại' : 'Tạo liên kết 1 giờ')),
      if (percent > 0 || (busy && session != null)) XProgress(percent: percent, done: done, count: files.length, bytes: bytes, total: total, stage: stage),
      if (error != null) Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
      if (link != null) XLinkActions(link: link!, onShare: _share),
      const SizedBox(height: 20),
      const Text('Liên kết X-Scan hết hạn sau 1 giờ. Bản sao Drive được thử xóa khi mở lại chức năng và có Internet; đường dẫn Drive trực tiếp có thể còn truy cập được cho đến khi xóa thành công.'),
    ]));
}
