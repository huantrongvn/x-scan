import 'dart:async';
import '../../core/cloud/x_scan_sync_service.dart';
import '../../core/ads/x_scan_ads.dart';
import 'package:flutter/material.dart';
import '../../core/localization/language.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../../core/auth/x_google_auth.dart';
import '../../core/kernel/x_kernel.dart';
import '../scan/scan_screen.dart';
import '../cloud/x_scan_cloud_screen.dart';
import '../settings/settings_screen.dart';
import '../share/x_share_screen.dart';
import '../transfer/x_transfer_screen.dart';


class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeState();
}

class _HomeState extends State<HomeScreen> with WidgetsBindingObserver {
  Timer? _syncTimer;
  bool _foreground = true;
  DateTime? _retryAfter;
  Future<void> _autoSync() async {
    if (_retryAfter?.isAfter(DateTime.now()) == true) return;
    final a = account;
    if (!mounted || !_foreground || a == null || authBusy || ScanScreen.activityBusy || ModalRoute.of(context)?.isCurrent != true || !XKernel.instance.allowed(XModule.cloud) || XScanSyncService.busy) return;
    final service = XScanSyncService();
    try { await service.sync(a, automatic: true); } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Cloud Sync: $e'))); _retryAfter = DateTime.now().add(Duration(minutes: e.toString().contains('storageQuotaExceeded') ? 60 : 10)); } finally { service.dispose(); }
  }
  @override void didChangeAppLifecycleState(AppLifecycleState state) {
    _foreground = state == AppLifecycleState.resumed;
    if (_foreground) unawaited(_autoSync());
  }
  @override void dispose() { _syncTimer?.cancel(); WidgetsBinding.instance.removeObserver(this); super.dispose(); }
  int tab = 0; // Scan | Dịch vụ | Tài khoản
  GoogleSignInAccount? account;
  bool authBusy = false;
  String? authError;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _syncTimer = Timer.periodic(const Duration(minutes: 1), (_) => unawaited(_autoSync()));
    final kernel = XKernel.instance;
    kernel.register(XModule.scan, (_) => const ScanScreen());
    kernel.register(XModule.share, (_) => const XShareScreen());
    kernel.register(XModule.transfer, (_) => const XTransferScreen());
    kernel.register(XModule.settings, (context) => Scaffold(appBar: AppBar(title: Text(XLanguage.t(context,'Settings','Cài đặt'))), body: const SettingsScreen()));
    if (!kernel.safeMode) _restoreAccount();
  }

  Future<void> _restoreAccount() async {
    try {
      final value = await XGoogleAuth.instance.restore();
      if (mounted) setState(() => account = value);
    } catch (_) {
      // No account or OAuth not configured yet; allow local-first use.
    }
  }

  Future<void> _login() async {
    setState(() { authBusy = true; authError = null; });
    try {
      final value = await XGoogleAuth.instance.signIn();
      if (mounted) setState(() => account = value);
    } catch (e) {
      if (mounted) setState(() => authError = 'Không đăng nhập được: $e');
    } finally {
      if (mounted) setState(() => authBusy = false);
    }
  }

  Future<void> _logout() async {
    setState(() { authBusy = true; authError = null; });
    try {
      await XGoogleAuth.instance.signOut();
      if (mounted) setState(() => account = null);
    } catch (e) {
      if (mounted) setState(() => authError = 'Không đăng xuất được: $e');
    } finally {
      if (mounted) setState(() => authBusy = false);
    }
  }

  Widget _services() => ListView(children: [
    ListTile(leading: const Icon(Icons.share_outlined), title: const Text('X-Share'), subtitle: Text(XLanguage.t(context,'Share photos via Google Drive','Chia sẻ ảnh qua Google Drive')), onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => XKernel.instance.screen(XModule.share)))),
    ListTile(leading: const Icon(Icons.computer_outlined), title: const Text('X-Transfer'), subtitle: Text(XLanguage.t(context,'Transfer files to computer – 1-hour link','Chuyển tệp đến máy tính – liên kết 1 giờ')), onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => XKernel.instance.screen(XModule.transfer)))),
  ]);

  Widget _profile() => ListView(padding: const EdgeInsets.all(20), children: [
    if (!XKernel.instance.allowed(XModule.cloud)) Text(XLanguage.t(context,'Cloud is temporarily disabled','Cloud đang tạm tắt')) ,
    if (XKernel.instance.allowed(XModule.cloud)) ...[
    CircleAvatar(radius:35, foregroundImage:account?.photoUrl == null ? null : NetworkImage(account!.photoUrl!), child: const Icon(Icons.person)),
    const SizedBox(height: 12),
    Center(child: Text(account?.displayName ?? XLanguage.t(context,'X-Scan account','Tài khoản X-Scan'), style: Theme.of(context).textTheme.titleLarge)),
    const SizedBox(height: 8),
    Center(child: Text(account?.email ?? XLanguage.t(context,'Sign in with Google to connect your account','Đăng nhập Google để kết nối tài khoản'))),
    const SizedBox(height: 24),
    if (authBusy) const Center(child: CircularProgressIndicator())
    else if (account == null) FilledButton.icon(onPressed: _login, icon: const Icon(Icons.login), label: Text(XLanguage.t(context,'Sign in with Google','Đăng nhập với Google')))
    else OutlinedButton.icon(onPressed: _logout, icon: const Icon(Icons.logout), label: Text(XLanguage.t(context,'Sign out','Đăng xuất'))),
    if (authError != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(authError!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
    if (account != null && XKernel.instance.allowed(XModule.cloud)) ListTile(leading: const Icon(Icons.cloud_sync), title: Text(XLanguage.t(context,'Scan Cloud Sync','Đồng bộ tài liệu')), onTap: authBusy ? null : () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => XScanCloudScreen(account: account!)))),
    ],
    ListTile(leading: const Icon(Icons.settings_outlined), title: Text(XLanguage.t(context,'Settings','Cài đặt')), onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => XKernel.instance.screen(XModule.settings)))),
    ListTile(leading: const Icon(Icons.health_and_safety_outlined), title: Text(XLanguage.t(context,'Safety and diagnostics','An toàn và chẩn đoán')), onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const CoreStatusScreen()))),
    const SizedBox(height: 16),
    Text(XLanguage.t(context,'Sign-in and Google Drive sync are optional. Documents remain on your device.','Đăng nhập và đồng bộ Google Drive là tùy chọn. Tài liệu vẫn được lưu trên thiết bị.')),
  ]);

  @override
  Widget build(BuildContext context) => Scaffold(
    // ScanScreen already owns its AppBar; do not show a second title.
    appBar: tab == 0 ? null : AppBar(title: Text(tab == 1 ? XLanguage.t(context,'Services','Dịch vụ') : XLanguage.t(context,'Account','Tài khoản'))),
    body: IndexedStack(index: tab, children: [XKernel.instance.screen(XModule.scan), _services(), ListenableBuilder(listenable: XKernel.instance, builder: (_, __) => _profile())]),
    bottomNavigationBar: Column(mainAxisSize: MainAxisSize.min, children: [if(tab != 0) const XScanBanner(), NavigationBar(
      selectedIndex: tab,
      onDestinationSelected: (index) => setState(() => tab = index),
      destinations: [
        NavigationDestination(icon: Icon(Icons.document_scanner_outlined), selectedIcon: Icon(Icons.document_scanner), label: 'X-Scan'),
        NavigationDestination(icon: Icon(Icons.apps_outlined), selectedIcon: Icon(Icons.apps), label: XLanguage.t(context,'Services','Dịch vụ')),
        NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: XLanguage.t(context,'Account','Tài khoản')),
      ],
    )]),
  );
}