import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'pdf_viewer_screen.dart';

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key});
  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  String _query = '';
  bool _trash = false;
  bool _duplicates = false;
  late Future<List<_Document>> _documents;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() {
    _documents = _load();
  }

  Future<Directory> _folder(String name) async {
    final root = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(root.path, 'checo', name));
    await dir.create(recursive: true);
    return dir;
  }

  Future<List<_Document>> _load() async {
    final dir = await _folder(_trash ? 'trash' : 'scan');
    final files = await dir
        .list()
        .where((e) => e is File && p.extension(e.path).toLowerCase() == '.pdf')
        .cast<File>()
        .toList();
    final documents = <_Document>[];
    for (final file in files) {
      String ocr = '';
      final sidecar = File('${file.path}.ocr.json');
      if (await sidecar.exists()) {
        try {
          ocr =
              (jsonDecode(
                await sidecar.readAsString(),
              ) as Map<String, dynamic>)['text']?.toString() ??
              '';
        } catch (_) {}
      }
      documents.add(_Document(file, ocr));
    }
    documents.sort(
      (a, b) => b.file.lastModifiedSync().compareTo(a.file.lastModifiedSync()),
    );
    return documents;
  }

  Future<Map<String, List<_Document>>> _exactDuplicates(
    List<_Document> docs,
  ) async {
    final groups = <String, List<_Document>>{};
    for (final d in docs) {
      final hash = await sha256.bind(d.file.openRead()).first;
      groups.putIfAbsent(hash.toString(), () => []).add(d);
    }
    groups.removeWhere((_, items) => items.length < 2);
    return groups;
  }

  Future<void> _move(_Document doc, bool restore) async {
    final destination = await _folder(restore ? 'scan' : 'trash');
    final originalName = p.basename(doc.file.path);
    var newPath = p.join(destination.path, originalName);
    if (await File(newPath).exists()) {
      newPath = p.join(
        destination.path,
        '${DateTime.now().microsecondsSinceEpoch}_$originalName',
      );
    }
    await doc.file.rename(newPath);
    final sidecar = File('${doc.file.path}.ocr.json');
    if (await sidecar.exists()) await sidecar.rename('$newPath.ocr.json');
    if (mounted) setState(_reload);
  }

  Future<void> _deleteForever(_Document doc) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Xóa vĩnh viễn?'),
        content: const Text(
          'Không thể khôi phục tài liệu sau thao tác này.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: const Text('Hủy'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(c, true),
            child: const Text('Xóa'),
          ),
        ],
      ),
    );
    if (confirm != true) return;
    final sidecar = File('${doc.file.path}.ocr.json');
    if (await sidecar.exists()) await sidecar.delete();
    await doc.file.delete();
    if (mounted) setState(_reload);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          _trash
              ? 'Thùng rác X-Scan'
              : _duplicates
              ? 'File trùng hoàn toàn'
              : 'Thư viện X-Scan',
        ),
        actions: [
          IconButton(
            tooltip: 'Làm mới',
            onPressed: () => setState(_reload),
            icon: const Icon(Icons.refresh),
          ),
          IconButton(
            tooltip: 'File trùng',
            onPressed: () => setState(() {
              _trash = false;
              _duplicates = !_duplicates;
              _reload();
            }),
            icon: Icon(
              _duplicates ? Icons.folder_outlined : Icons.content_copy_outlined,
            ),
          ),
          IconButton(
            tooltip: 'Thùng rác',
            onPressed: () => setState(() {
              _trash = !_trash;
              _duplicates = false;
              _reload();
            }),
            icon: Icon(_trash ? Icons.folder_outlined : Icons.delete_outline),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: 'Tìm tên file hoặc nội dung OCR',
                border: OutlineInputBorder(),
              ),
              onChanged: (v) => setState(() => _query = v.trim().toLowerCase()),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<_Document>>(
              future: _documents,
              builder: (context, snapshot) {
                if (!snapshot.hasData)
                  return Center(
                    child: snapshot.hasError
                        ? Text('Lỗi: ${snapshot.error}')
                        : const CircularProgressIndicator(),
                  );
                final all = snapshot.data!;
                return FutureBuilder<Map<String, List<_Document>>>(
                  future: _duplicates
                      ? _exactDuplicates(all)
                      : Future.value(<String, List<_Document>>{}),
                  builder: (context, duplicateSnapshot) {
                    if (_duplicates && !duplicateSnapshot.hasData)
                      return const Center(child: CircularProgressIndicator());
                    final allowed = _duplicates
                        ? duplicateSnapshot.data!.values
                              .expand((g) => g)
                              .map((d) => d.file.path)
                              .toSet()
                        : null;
                    final docs = all
                        .where(
                          (d) =>
                              (allowed == null ||
                                  allowed.contains(d.file.path)) &&
                              (p
                                      .basename(d.file.path)
                                      .toLowerCase()
                                      .contains(_query) ||
                                  d.ocr.toLowerCase().contains(_query)),
                        )
                        .toList();
                    if (docs.isEmpty)
                      return Center(
                        child: Text(
                          _duplicates
                              ? 'Không có PDF trùng hoàn toàn.'
                              : 'Không tìm thấy tài liệu.',
                        ),
                      );
                    return RefreshIndicator(
                      onRefresh: () async {
                        setState(_reload);
                        await _documents;
                      },
                      child: ListView.separated(
                        itemCount: docs.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (context, i) {
                          final d = docs[i];
                          return ListTile(
                            leading: const Icon(Icons.picture_as_pdf_outlined),
                            title: Text(
                              p.basename(d.file.path),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            subtitle: Text(
                              '${(d.file.lengthSync() / 1024).toStringAsFixed(1)} KB${d.ocr.isEmpty ? '' : ' · Có OCR'}',
                            ),
                            onTap: _trash
                                ? null
                                : () async {
                                    await Navigator.push(
                                      context,
                                      MaterialPageRoute<void>(
                                        builder: (_) =>
                                            XPdfViewerScreen(file: d.file),
                                      ),
                                    );
                                    if (mounted) setState(_reload);
                                  },
                            trailing: PopupMenuButton<String>(
                              onSelected: (action) async {
                                if (action == 'trash') await _move(d, false);
                                if (action == 'restore') await _move(d, true);
                                if (action == 'delete') await _deleteForever(d);
                              },
                              itemBuilder: (_) => _trash
                                  ? [
                                      const PopupMenuItem(
                                        value: 'restore',
                                        child: Text('Khôi phục'),
                                      ),
                                      const PopupMenuItem(
                                        value: 'delete',
                                        child: Text('Xóa vĩnh viễn'),
                                      ),
                                    ]
                                  : [
                                      const PopupMenuItem(
                                        value: 'trash',
                                        child: Text(
                                          'Chuyển vào thùng rác',
                                        ),
                                      ),
                                    ],
                            ),
                          );
                        },
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _Document {
  const _Document(this.file, this.ocr);
  final File file;
  final String ocr;
}
