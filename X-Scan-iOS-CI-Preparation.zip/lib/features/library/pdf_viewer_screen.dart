import '../../core/export/x_pdf_exporter.dart';

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:pdfx/pdfx.dart';

import '../scan/ocr_screen.dart';

class XPdfViewerScreen extends StatefulWidget {
  const XPdfViewerScreen({super.key, required this.file});
  final File file;

  @override
  State<XPdfViewerScreen> createState() => _XPdfViewerScreenState();
}

class _XPdfViewerScreenState extends State<XPdfViewerScreen> {
  late final PdfControllerPinch _controller;

  @override
  void initState() {
    super.initState();
    _controller = PdfControllerPinch(
      document: PdfDocument.openFile(widget.file.path),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _share() async {
    await XPdfExporter.export(context, widget.file);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.file.uri.pathSegments.last,
          overflow: TextOverflow.ellipsis,
        ),
        actions: [
          IconButton(
            tooltip: 'OCR tieng Viet/Anh',
            icon: const Icon(Icons.text_snippet_outlined),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => XOcrScreen(file: widget.file),
              ),
            ),
          ),
          IconButton(
            tooltip: 'Chia se PDF',
            icon: const Icon(Icons.share_outlined),
            onPressed: _share,
          ),
        ],
      ),
      body: PdfViewPinch(controller: _controller),
    );
  }
}
