import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../../core/cloud/x_scan_sync_service.dart';

class XScanCloudScreen extends StatefulWidget {
  const XScanCloudScreen({super.key, required this.account, this.folderId});
  final GoogleSignInAccount account;
  final String? folderId;
  @override
  State<XScanCloudScreen> createState() => _CloudState();
}
class _CloudState extends State<XScanCloudScreen> {
  bool busy = false;
  String message = '';
  Future<void> run() async {
    setState(() { busy = true; message = ''; });
    final service = XScanSyncService();
    try {
      final result = await service.sync(widget.account, folderId: widget.folderId);
      if (mounted) setState(() => message = result);
    } catch (e) {
      if (mounted) setState(() => message = 'Đồng bộ chưa hoàn tất: $e');
    } finally {
      service.dispose();
      if (mounted) setState(() => busy = false);
    }
  }
  @override
  Widget build(BuildContext context) => PopScope(canPop: !busy, child: Scaffold(
    appBar: AppBar(title: const Text('Scan Cloud Sync')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Text(widget.account.email),
      const Text('Google Drive riêng tư. Free: 100 MB / 20 thư mục. Tự động ưu tiên ghim, sau đó sao. Đồng bộ ngay sẽ xét cả thư mục thường từ cũ đến mới. Chỉ cập nhật khi xác định được phiên bản gốc; giữ nguyên khi xung đột. File còn thiếu có thể được khôi phục khi đồng bộ.'),
      const SizedBox(height: 16),
      FilledButton(onPressed: busy ? null : run, child: const Text('Đồng bộ ngay')),
      if (busy) const LinearProgressIndicator(),
      Text(message),
    ]),
  ));
}
