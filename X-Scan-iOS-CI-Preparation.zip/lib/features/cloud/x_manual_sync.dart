import 'package:flutter/material.dart';
import '../../core/auth/x_google_auth.dart';
import '../../core/kernel/x_kernel.dart';
import 'x_scan_cloud_screen.dart';
Future<void> openManualSync(BuildContext context, {String? folderId}) async {
  try {
    if (!XKernel.instance.allowed(XModule.cloud)) throw StateError('Cloud đang bị tắt');
    final account=await XGoogleAuth.instance.restore();
    if (!context.mounted) return;
    if(account==null) throw StateError('Đăng nhập Google trong Tài khoản trước');
    await Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>XScanCloudScreen(account:account,folderId:folderId)));
  } catch(e) {
    if(context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));
  }
}
