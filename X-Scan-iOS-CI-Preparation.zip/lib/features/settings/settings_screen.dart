import 'package:url_launcher/url_launcher.dart';
import '../../core/ads/x_scan_ads.dart';
import 'package:flutter/material.dart';
import '../../core/localization/language.dart';
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});
  @override Widget build(BuildContext context)=>ListenableBuilder(listenable:XLanguage.instance,builder:(context,child)=>ListView(children:[
    ListTile(leading:const Icon(Icons.language),title:Text(XLanguage.t(context,'Language','Ngôn ngữ')),subtitle:Text(XLanguage.instance.value == 'system' ? XLanguage.t(context,'System default','Theo hệ thống') : XLanguage.names[XLanguage.instance.value]!),trailing:const Icon(Icons.chevron_right),onTap:() async {
      final selected=await showDialog<String>(context:context,builder:(context)=>SimpleDialog(title:Text(XLanguage.t(context,'Language','Ngôn ngữ')),children:[for(final e in XLanguage.names.entries) SimpleDialogOption(onPressed:()=>Navigator.pop(context,e.key),child:Row(children:[Expanded(child:Text(e.key == 'system' ? XLanguage.t(context,'System default','Theo hệ thống') : e.value)),if(e.key==XLanguage.instance.value)const Icon(Icons.check)]) )]));
      if(selected!=null) await XLanguage.instance.select(selected);
    }),
    ListTile(leading:const Icon(Icons.info_outline),title:Text(XLanguage.t(context,'About','Giới thiệu')),subtitle:const Text('X-Scan · 1.0.0'),onTap:()=>Navigator.push(context,MaterialPageRoute<void>(builder: (ctx)=>Scaffold(appBar:AppBar(title:Text(XLanguage.t(ctx,'About','Giới thiệu'))),body:ListView(padding:const EdgeInsets.all(24),children:[Image.asset('assets/xscan_icon.png',height:80),const Center(child:Text('X-Scan · 1.0.0 (33)')),const Center(child:Text('Scan. Organize. Share.')),const SizedBox(height:20),Text(XLanguage.t(ctx,'Scan, edit, organize and share documents. Export PDF and images; sync with Google Drive.','Quét, chỉnh sửa, quản lý và chia sẻ tài liệu. Xuất PDF, ảnh và đồng bộ Google Drive.')),ListTile(leading:const Icon(Icons.mail),title:const Text('huan.at5b@gmail.com'),onTap:()=>launchUrl(Uri.parse('mailto:huan.at5b@gmail.com'))),const XScanBanner()]))))),
  ]));
}
