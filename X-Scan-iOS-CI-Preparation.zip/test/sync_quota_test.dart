import 'package:flutter_test/flutter_test.dart';
import 'package:x_scan/core/cloud/x_sync_quota.dart';
void main() {
  bool check(int bytes, int folders, int extra, int added) => XSyncQuota.canUpload(currentBytes: bytes, currentFolders: folders, uploadBytes: extra, newFolders: added);
  test('configured limits', () { expect(XSyncQuota.freeBytes, 100 * 1024 * 1024); expect(XSyncQuota.freeFolders, 20); });
  test('exact limits allowed', () => expect(check(XSyncQuota.freeBytes, 20, 0, 0), isTrue));
  test('one byte too many rejected', () => expect(check(XSyncQuota.freeBytes, 1, 1, 0), isFalse));
  test('twenty-first folder rejected', () => expect(check(0, 20, 1, 1), isFalse));
  test('existing folder can grow', () => expect(check(0, 20, 1, 0), isTrue));
  test('negative values rejected', () => expect(check(0, 1, -1, 0), isFalse));
}
