package com.checo.checo
import android.net.Uri
import android.os.Build
import android.content.ContentValues
import android.provider.MediaStore
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "xscan/gallery").setMethodCallHandler { call, result ->
            if (call.method != "save") { result.notImplemented(); return@setMethodCallHandler }
            Thread {
                var uri: Uri? = null
                try {
                    require(Build.VERSION.SDK_INT >= 29) { "Gallery export requires Android 10 or newer" }
                    val file = File(call.arguments as String)
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "${System.currentTimeMillis()}_${file.name}")
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/X-Scan")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                    val target = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: error("Cannot create image")
                    uri = target
                    contentResolver.openOutputStream(target)?.use { out -> file.inputStream().use { it.copyTo(out) } } ?: error("Cannot open image")
                    contentResolver.update(target, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
                    runOnUiThread { result.success(null) }
                } catch (e: Exception) {
                    uri?.let { try { contentResolver.delete(it, null, null) } catch (_: Exception) {} }
                    runOnUiThread { result.error("GALLERY", e.message, null) }
                }
            }.start()
        }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "checo/scan_uri").setMethodCallHandler { call, result ->
            if (call.method != "copyImage") { result.notImplemented(); return@setMethodCallHandler }
            try {
                val uri = Uri.parse(call.arguments as String)
                require(uri.scheme == "content")
                val output = File.createTempFile("scan_", ".jpg", cacheDir)
                contentResolver.openInputStream(uri)?.use { input -> output.outputStream().use { input.copyTo(it) } } ?: error("Cannot open URI")
                result.success(output.absolutePath)
            } catch (e: Exception) { result.error("URI_READ", e.message, null) }
        }
    }
}
