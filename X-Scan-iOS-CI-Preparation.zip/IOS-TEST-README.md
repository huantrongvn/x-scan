# X-Scan iPhone testing preparation

This package is the Build 33 Flutter source plus a GitHub Actions macOS **unsigned compile-check** workflow. It is NOT an IPA and cannot be installed on an iPhone yet.

1. Create a PRIVATE GitHub repository and upload the contents of this package to the repository ROOT (pubspec.yaml at root). Do not upload signing certificates, API secrets, or private keys.
2. GitHub > Actions > X-Scan iOS compile check > Run workflow. Monitor the build errors. macOS hosted runners consume GitHub Actions minutes; check your plan and limits.
3. If it succeeds, download the unsigned Runner.app artifact to inspect. It is NOT signed and cannot be installed on an ordinary iPhone.
4. To install on a real iPhone without a Mac, use an Apple Developer Program membership and a cloud macOS CI that supports signing, a valid iOS Development or Ad Hoc provisioning profile including the device UDID, and matching certificate/private key. TestFlight instead requires App Store Connect and Apple Developer membership. Do not share private signing material in chat.
5. Before any signed build, configure a unique iOS bundle ID, Google Sign-In iOS client ID/URL scheme, camera/photo permissions, iOS AdMob app ID, icons and minimum iOS deployment target; verify native scanner and MediaStore/platform-specific code.

Caveats: Build 33 source has no ios/ directory; workflow generates it. Build33 has not been compiled on macOS or tested on iPhone. Build33 My Drive migration must be tested with backed-up data; do not treat an unsigned build as production ready. The bundled scanner plugin includes iOS source but compatibility is not yet verified.

No paid Apple membership is needed for unsigned compile checks; a paid Apple membership is the practical requirement for cloud-based signing/distribution to an iPhone. A free Apple ID with local Xcode can sign to a connected iPhone, but requires access to a Mac and is not the cloud route here.
